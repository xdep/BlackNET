﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.FormSkin1 = New BlackNet_Builder.FormSkin()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.FlatTextBox5 = New BlackNet_Builder.FlatTextBox()
        Me.FlatLabel5 = New BlackNet_Builder.FlatLabel()
        Me.FlatComboBox1 = New BlackNet_Builder.FlatComboBox()
        Me.FlatCheckBox7 = New BlackNet_Builder.FlatCheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.FlatCheckBox6 = New BlackNet_Builder.FlatCheckBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FlatCheckBox5 = New BlackNet_Builder.FlatCheckBox()
        Me.FlatCheckBox4 = New BlackNet_Builder.FlatCheckBox()
        Me.FlatCheckBox3 = New BlackNet_Builder.FlatCheckBox()
        Me.FlatCheckBox2 = New BlackNet_Builder.FlatCheckBox()
        Me.FlatClose1 = New BlackNet_Builder.FlatClose()
        Me.FlatCheckBox1 = New BlackNet_Builder.FlatCheckBox()
        Me.FlatTextBox3 = New BlackNet_Builder.FlatTextBox()
        Me.FlatTextBox2 = New BlackNet_Builder.FlatTextBox()
        Me.FlatTextBox1 = New BlackNet_Builder.FlatTextBox()
        Me.FlatLabel3 = New BlackNet_Builder.FlatLabel()
        Me.FlatLabel2 = New BlackNet_Builder.FlatLabel()
        Me.FlatLabel1 = New BlackNet_Builder.FlatLabel()
        Me.FlatButton1 = New BlackNet_Builder.FlatButton()
        Me.FlatLabel6 = New BlackNet_Builder.FlatLabel()
        Me.FormSkin1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FormSkin1
        '
        Me.FormSkin1.BackColor = System.Drawing.Color.White
        Me.FormSkin1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FormSkin1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.FormSkin1.Controls.Add(Me.TextBox2)
        Me.FormSkin1.Controls.Add(Me.FlatTextBox5)
        Me.FormSkin1.Controls.Add(Me.FlatLabel5)
        Me.FormSkin1.Controls.Add(Me.FlatComboBox1)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox7)
        Me.FormSkin1.Controls.Add(Me.TextBox1)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox6)
        Me.FormSkin1.Controls.Add(Me.PictureBox1)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox5)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox4)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox3)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox2)
        Me.FormSkin1.Controls.Add(Me.FlatClose1)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox1)
        Me.FormSkin1.Controls.Add(Me.FlatTextBox3)
        Me.FormSkin1.Controls.Add(Me.FlatTextBox2)
        Me.FormSkin1.Controls.Add(Me.FlatTextBox1)
        Me.FormSkin1.Controls.Add(Me.FlatLabel3)
        Me.FormSkin1.Controls.Add(Me.FlatLabel2)
        Me.FormSkin1.Controls.Add(Me.FlatLabel1)
        Me.FormSkin1.Controls.Add(Me.FlatButton1)
        Me.FormSkin1.Controls.Add(Me.FlatLabel6)
        Me.FormSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormSkin1.FlatColor = System.Drawing.Color.DeepSkyBlue
        Me.FormSkin1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FormSkin1.HeaderColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FormSkin1.HeaderMaximize = False
        Me.FormSkin1.Location = New System.Drawing.Point(0, 0)
        Me.FormSkin1.Name = "FormSkin1"
        Me.FormSkin1.Size = New System.Drawing.Size(284, 505)
        Me.FormSkin1.TabIndex = 0
        Me.FormSkin1.Text = "BlackNET Builder"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(324, 371)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(160, 97)
        Me.TextBox2.TabIndex = 23
        '
        'FlatTextBox5
        '
        Me.FlatTextBox5.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox5.Enabled = False
        Me.FlatTextBox5.Location = New System.Drawing.Point(64, 229)
        Me.FlatTextBox5.MaxLength = 32767
        Me.FlatTextBox5.Multiline = False
        Me.FlatTextBox5.Name = "FlatTextBox5"
        Me.FlatTextBox5.ReadOnly = False
        Me.FlatTextBox5.Size = New System.Drawing.Size(206, 29)
        Me.FlatTextBox5.TabIndex = 22
        Me.FlatTextBox5.Text = "svchost.exe"
        Me.FlatTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox5.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox5.UseSystemPasswordChar = False
        '
        'FlatLabel5
        '
        Me.FlatLabel5.AutoSize = True
        Me.FlatLabel5.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel5.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel5.ForeColor = System.Drawing.Color.White
        Me.FlatLabel5.Location = New System.Drawing.Point(2, 236)
        Me.FlatLabel5.Name = "FlatLabel5"
        Me.FlatLabel5.Size = New System.Drawing.Size(66, 13)
        Me.FlatLabel5.TabIndex = 20
        Me.FlatLabel5.Text = "File Name : "
        '
        'FlatComboBox1
        '
        Me.FlatComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox1.DisplayMember = "T"
        Me.FlatComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox1.Enabled = False
        Me.FlatComboBox1.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox1.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox1.FormattingEnabled = True
        Me.FlatComboBox1.HoverColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatComboBox1.ItemHeight = 18
        Me.FlatComboBox1.Items.AddRange(New Object() {"Temp ", "AppData", "UserProfile", "ProgramData", "WinDir"})
        Me.FlatComboBox1.Location = New System.Drawing.Point(64, 193)
        Me.FlatComboBox1.Name = "FlatComboBox1"
        Me.FlatComboBox1.Size = New System.Drawing.Size(206, 24)
        Me.FlatComboBox1.TabIndex = 19
        Me.FlatComboBox1.Tag = ""
        '
        'FlatCheckBox7
        '
        Me.FlatCheckBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox7.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatCheckBox7.Checked = False
        Me.FlatCheckBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox7.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox7.Location = New System.Drawing.Point(3, 331)
        Me.FlatCheckBox7.Name = "FlatCheckBox7"
        Me.FlatCheckBox7.Options = BlackNet_Builder.FlatCheckBox._Options.Style1
        Me.FlatCheckBox7.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox7.TabIndex = 18
        Me.FlatCheckBox7.Text = "Stealth Mode"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(310, 255)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(119, 79)
        Me.TextBox1.TabIndex = 15
        '
        'FlatCheckBox6
        '
        Me.FlatCheckBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox6.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox6.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatCheckBox6.Checked = False
        Me.FlatCheckBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox6.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox6.Location = New System.Drawing.Point(3, 275)
        Me.FlatCheckBox6.Name = "FlatCheckBox6"
        Me.FlatCheckBox6.Options = BlackNet_Builder.FlatCheckBox._Options.Style1
        Me.FlatCheckBox6.Size = New System.Drawing.Size(139, 22)
        Me.FlatCheckBox6.TabIndex = 14
        Me.FlatCheckBox6.Text = "RSA Encryption"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(121, 424)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(40, 40)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'FlatCheckBox5
        '
        Me.FlatCheckBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox5.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatCheckBox5.Checked = False
        Me.FlatCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox5.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox5.Location = New System.Drawing.Point(3, 442)
        Me.FlatCheckBox5.Name = "FlatCheckBox5"
        Me.FlatCheckBox5.Options = BlackNet_Builder.FlatCheckBox._Options.Style1
        Me.FlatCheckBox5.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox5.TabIndex = 12
        Me.FlatCheckBox5.Text = "Change Icon"
        '
        'FlatCheckBox4
        '
        Me.FlatCheckBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox4.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatCheckBox4.Checked = False
        Me.FlatCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox4.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox4.Location = New System.Drawing.Point(3, 415)
        Me.FlatCheckBox4.Name = "FlatCheckBox4"
        Me.FlatCheckBox4.Options = BlackNet_Builder.FlatCheckBox._Options.Style1
        Me.FlatCheckBox4.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox4.TabIndex = 11
        Me.FlatCheckBox4.Text = "USB Spread"
        '
        'FlatCheckBox3
        '
        Me.FlatCheckBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox3.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatCheckBox3.Checked = False
        Me.FlatCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox3.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox3.Location = New System.Drawing.Point(3, 387)
        Me.FlatCheckBox3.Name = "FlatCheckBox3"
        Me.FlatCheckBox3.Options = BlackNet_Builder.FlatCheckBox._Options.Style1
        Me.FlatCheckBox3.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox3.TabIndex = 10
        Me.FlatCheckBox3.Text = "Bypass VM"
        '
        'FlatCheckBox2
        '
        Me.FlatCheckBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox2.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatCheckBox2.Checked = False
        Me.FlatCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox2.Location = New System.Drawing.Point(3, 359)
        Me.FlatCheckBox2.Name = "FlatCheckBox2"
        Me.FlatCheckBox2.Options = BlackNet_Builder.FlatCheckBox._Options.Style1
        Me.FlatCheckBox2.Size = New System.Drawing.Size(189, 22)
        Me.FlatCheckBox2.TabIndex = 9
        Me.FlatCheckBox2.Text = "Bypass Scanning Softwares"
        '
        'FlatClose1
        '
        Me.FlatClose1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatClose1.BackColor = System.Drawing.Color.White
        Me.FlatClose1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.FlatClose1.Font = New System.Drawing.Font("Marlett", 10.0!)
        Me.FlatClose1.Location = New System.Drawing.Point(266, 0)
        Me.FlatClose1.Name = "FlatClose1"
        Me.FlatClose1.Size = New System.Drawing.Size(18, 18)
        Me.FlatClose1.TabIndex = 8
        Me.FlatClose1.Text = "FlatClose1"
        Me.FlatClose1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatCheckBox1
        '
        Me.FlatCheckBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox1.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatCheckBox1.Checked = False
        Me.FlatCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox1.Location = New System.Drawing.Point(3, 303)
        Me.FlatCheckBox1.Name = "FlatCheckBox1"
        Me.FlatCheckBox1.Options = BlackNet_Builder.FlatCheckBox._Options.Style1
        Me.FlatCheckBox1.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox1.TabIndex = 7
        Me.FlatCheckBox1.Text = "Add to Startup"
        '
        'FlatTextBox3
        '
        Me.FlatTextBox3.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox3.Location = New System.Drawing.Point(64, 152)
        Me.FlatTextBox3.MaxLength = 32767
        Me.FlatTextBox3.Multiline = False
        Me.FlatTextBox3.Name = "FlatTextBox3"
        Me.FlatTextBox3.ReadOnly = False
        Me.FlatTextBox3.Size = New System.Drawing.Size(206, 29)
        Me.FlatTextBox3.TabIndex = 6
        Me.FlatTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox3.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox3.UseSystemPasswordChar = False
        '
        'FlatTextBox2
        '
        Me.FlatTextBox2.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox2.Location = New System.Drawing.Point(64, 109)
        Me.FlatTextBox2.MaxLength = 32767
        Me.FlatTextBox2.Multiline = False
        Me.FlatTextBox2.Name = "FlatTextBox2"
        Me.FlatTextBox2.ReadOnly = False
        Me.FlatTextBox2.Size = New System.Drawing.Size(206, 29)
        Me.FlatTextBox2.TabIndex = 5
        Me.FlatTextBox2.Text = "HacKed"
        Me.FlatTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox2.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox2.UseSystemPasswordChar = False
        '
        'FlatTextBox1
        '
        Me.FlatTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox1.Location = New System.Drawing.Point(64, 65)
        Me.FlatTextBox1.MaxLength = 32767
        Me.FlatTextBox1.Multiline = False
        Me.FlatTextBox1.Name = "FlatTextBox1"
        Me.FlatTextBox1.ReadOnly = False
        Me.FlatTextBox1.Size = New System.Drawing.Size(206, 29)
        Me.FlatTextBox1.TabIndex = 4
        Me.FlatTextBox1.Text = "http://localhost/blacknet"
        Me.FlatTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox1.UseSystemPasswordChar = False
        '
        'FlatLabel3
        '
        Me.FlatLabel3.AutoSize = True
        Me.FlatLabel3.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel3.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel3.ForeColor = System.Drawing.Color.White
        Me.FlatLabel3.Location = New System.Drawing.Point(15, 158)
        Me.FlatLabel3.Name = "FlatLabel3"
        Me.FlatLabel3.Size = New System.Drawing.Size(52, 13)
        Me.FlatLabel3.TabIndex = 3
        Me.FlatLabel3.Text = "MUTEX : "
        '
        'FlatLabel2
        '
        Me.FlatLabel2.AutoSize = True
        Me.FlatLabel2.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel2.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel2.ForeColor = System.Drawing.Color.White
        Me.FlatLabel2.Location = New System.Drawing.Point(5, 116)
        Me.FlatLabel2.Name = "FlatLabel2"
        Me.FlatLabel2.Size = New System.Drawing.Size(61, 13)
        Me.FlatLabel2.TabIndex = 2
        Me.FlatLabel2.Text = "Victim ID : "
        '
        'FlatLabel1
        '
        Me.FlatLabel1.AutoSize = True
        Me.FlatLabel1.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel1.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel1.ForeColor = System.Drawing.Color.White
        Me.FlatLabel1.Location = New System.Drawing.Point(12, 72)
        Me.FlatLabel1.Name = "FlatLabel1"
        Me.FlatLabel1.Size = New System.Drawing.Size(53, 13)
        Me.FlatLabel1.TabIndex = 1
        Me.FlatLabel1.Text = "BN URL : "
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton1.BaseColor = System.Drawing.Color.DeepSkyBlue
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.FlatButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton1.Location = New System.Drawing.Point(0, 473)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(284, 32)
        Me.FlatButton1.TabIndex = 0
        Me.FlatButton1.Text = "Combile Client"
        Me.FlatButton1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatLabel6
        '
        Me.FlatLabel6.AutoSize = True
        Me.FlatLabel6.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel6.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel6.ForeColor = System.Drawing.Color.White
        Me.FlatLabel6.Location = New System.Drawing.Point(28, 197)
        Me.FlatLabel6.Name = "FlatLabel6"
        Me.FlatLabel6.Size = New System.Drawing.Size(39, 13)
        Me.FlatLabel6.TabIndex = 21
        Me.FlatLabel6.Text = "Path : "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(284, 505)
        Me.Controls.Add(Me.FormSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Blacknet Builder v1.0"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.FormSkin1.ResumeLayout(False)
        Me.FormSkin1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FormSkin1 As BlackNet_Builder.FormSkin
    Friend WithEvents FlatTextBox3 As BlackNet_Builder.FlatTextBox
    Friend WithEvents FlatTextBox2 As BlackNet_Builder.FlatTextBox
    Friend WithEvents FlatTextBox1 As BlackNet_Builder.FlatTextBox
    Friend WithEvents FlatLabel3 As BlackNet_Builder.FlatLabel
    Friend WithEvents FlatLabel2 As BlackNet_Builder.FlatLabel
    Friend WithEvents FlatLabel1 As BlackNet_Builder.FlatLabel
    Friend WithEvents FlatButton1 As BlackNet_Builder.FlatButton
    Friend WithEvents FlatCheckBox1 As BlackNet_Builder.FlatCheckBox
    Friend WithEvents FlatClose1 As BlackNet_Builder.FlatClose
    Friend WithEvents FlatCheckBox3 As BlackNet_Builder.FlatCheckBox
    Friend WithEvents FlatCheckBox2 As BlackNet_Builder.FlatCheckBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents FlatCheckBox5 As BlackNet_Builder.FlatCheckBox
    Friend WithEvents FlatCheckBox4 As BlackNet_Builder.FlatCheckBox
    Friend WithEvents FlatCheckBox6 As BlackNet_Builder.FlatCheckBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents FlatCheckBox7 As BlackNet_Builder.FlatCheckBox
    Friend WithEvents FlatTextBox5 As BlackNet_Builder.FlatTextBox
    Friend WithEvents FlatLabel5 As BlackNet_Builder.FlatLabel
    Friend WithEvents FlatComboBox1 As BlackNet_Builder.FlatComboBox
    Friend WithEvents FlatLabel6 As BlackNet_Builder.FlatLabel
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox

End Class
