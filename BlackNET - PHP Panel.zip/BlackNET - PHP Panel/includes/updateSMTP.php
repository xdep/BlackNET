<?php 
require '../classes/Database.php';
require '../classes/Mailer.php';
include '../session.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $smtp = new Mailer;
  $msg = $smtp->setSMTP($_POST['id'],$_POST['SMTPHost'],$_POST['SMTPUser'],$_POST['SMTPPassword'],$_POST['SMTPPort'],$_POST['security'],$_POST['status-state']);
  exit(header("Location: ../settings.php?msg=yes"));
}
?>