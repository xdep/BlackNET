<?php 
require '../classes/Database.php';
require '../classes/Settings.php';
include('session.php');
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $id = $_POST['id'];
  $recaptchaprivate = $_POST['reCaptchaPrivate'];
  $recaptchapublic = $_POST['reCaptchaPublic'];
  $status = $_POST['status-state'];
  $settings = new Settings;
  $msg = $settings->updateSettings($id,$recaptchaprivate,$recaptchapublic,$status);
  exit(header("Location: ../settings.php?msg=yes"));
}
?>