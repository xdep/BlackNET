<?php
include 'classes/Database.php';
include 'classes/Settings.php';
include 'classes/Mailer.php';
include('session.php');

if ($login_session != $data->username){
    exit(header("Location: logout.php"));
}

$database = new Database;
$database->dataExist();

$settings = new Settings;
$getSettings = $settings->getSettings(1);

$smtp = new Mailer;
$getSMTP = $smtp->getSMTP(1);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
     <link rel="shortcut icon" href="favico.png">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>BlackNET - Network Settings</title>
    <link href="asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="asset/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="asset/css/sb-admin.css" rel="stylesheet">
    <link href="asset/css/bootstrap-switch.css" rel="stylesheet">
    <style type="text/css">
    @media (min-width: 1200px) {
        .container{
            max-width: 500px;
        }
    }
      .sticky{
        display: -webkit-box;
        display: -ms-flexbox;
        background-color: #e9ecef;
        height: 80px;
        right: 0;
        bottom: 0; 
        position: absolute;
        display: flex;
        width: 100%;
        flex-shrink: none;
      }
    </style>
  </head>

  <body id="page-top">
    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
      <a class="navbar-brand mr-1" href="index.php"><img src="favico.png" width="30" height="30" alt="">BlackNET</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php"><span class="fa fa-home"></span> Home</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="settings.php"><span class="fa fa-wrench"></span> Settings</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="changePassword.php"><span class="fa fa-user"></span> Change Password</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="modal" data-target="#logoutModal"><span class="fa fa-sign-out-alt"></span> Logout</a>
      </li>
    </ul>
  </div>
    </nav>
    <div id="wrapper">
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">User Settings</a>
            </li>
          </ol>
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas  fa-user-circle"></i>
              Update Settings</div>
              <div class="card-body">
          <form id="Form1" name="Form1" method="POST" action="includes/updateSettings.php">
            
              <div class="container">
              <?php if (isset($_GET['msg']) && $_GET['msg'] == "yes"): ?>
                <div class="alert alert-success">
                  <span class="fa fa-check-circle"></span> Settings Has Been Updated
                </div>
              <?php endif; ?>
            </div>
              <div class="container">
                <div class="align-content-center justify-content-center">
                <input hidden="" value="<?php echo $getSettings->id ?>" name="id" id="id">

                  <div class="form-group">             
                    <div class="form-group">
                       <label for="switch-state">Enable reCAPTCHA: </label>
                      <input class="bootstrap-switch" id="status-state" name="status-state" type="checkbox" data-size="small" <?php if ($getSettings->recaptchastatus == "on") { echo 'checked'; } ?>>
                    </div>
                  </div>

                <div class="form-group">        
                  <div class="form-label-group">
                    <input class="form-control" type="text" id="reCaptchaPublic" name="reCaptchaPublic" placeholder="reCAPTCHA Public Key" value="<?php echo $getSettings->recaptchapublic; ?>">
                    <label for="reCaptchaPublic">reCAPTCHA Public Key</label>
                  </div>
                </div>

                  <div class="form-group">
                   <div class="form-label-group">
                     <input class="form-control" type="text" id="reCaptchaPrivate" name="reCaptchaPrivate" placeholder="reCAPTCHA Public Key" value="<?php echo $getSettings->recaptchaprivate; ?>">
                    <label for="reCaptchaPrivate">reCAPTCHA Private Key</label>
                  </div>
                  </div>


                  <button for="Form1" class="btn btn-primary btn-block">Update Settings</button>
                </div>
            </div>

          
      </form>
      <hr>
      <form id="Form2" name="Form2" method="POST" action="includes/updateSMTP.php" class="pt-2">
        <div class="container" class="align-content-center justify-content-center">

                <input hidden="" value="<?php echo $getSMTP->id ?>" name="id" id="id">
               <div class="form-group">             
                <div class="form-group">
                    <label for="switch-state">Enable SMTP: </label>
                    <input class="bootstrap-switch" id="status-state" name="status-state" type="checkbox" data-size="small" <?php if ($getSMTP->status == "on") { echo 'checked'; } ?>>
                  </div>
                </div>

                <div class="form-group">        
                  <div class="form-label-group">
                    <input class="form-control" type="text" id="SMTPHost" name="SMTPHost" placeholder="SMTP Host" value="<?php echo $getSMTP->smtphost; ?>">
                    <label for="SMTPHost">SMTP Host</label>
                  </div>
                </div>

                  <div class="form-group">
                   <div class="form-label-group">
                     <input class="form-control" type="text" id="SMTPUser" name="SMTPUser" placeholder="SMTP User" value="<?php echo $getSMTP->smtpuser; ?>">
                    <label for="SMTPUser">SMTP User</label>
                  </div>
                  </div>

                  <div class="form-group">
                   <div class="form-label-group">
                     <input class="form-control" type="password" id="SMTPPassword" name="SMTPPassword" placeholder="SMTP Password" value="<?php echo base64_decode($getSMTP->smtppassword); ?>">
                      <label for="SMTPPassword">SMTP Password</label>
                  </div>
                  </div>

                  <div class="form-group">
                    <select label="Select a Security type" name="security" id="security" class="form-control">
                      <option>Select a Security type</option>
                      <option value="none" <?php if ($getSMTP->security_type == "none") { echo "selected"; } ?>>None</option>
                      <option value="ssl" <?php if ($getSMTP->security_type == "ssl") { echo "selected"; } ?>>SSL</option>
                      <option value="tls" <?php if ($getSMTP->security_type == "tls") { echo "selected"; } ?>>TLS</option>
                    </select>
                  </div>

                  <div class="form-group">
                   <div class="form-label-group">
                     <input class="form-control" type="text" id="SMTPPort" name="SMTPPort" placeholder="SMTP Port" value="<?php echo $getSMTP->port; ?>">
                    <label for="SMTPPort">SMTP Port</label>
                  </div>
                  </div>
          <button for="Form2" class="btn btn-primary btn-block">Update SMTP</button>
        </div>
      </form>
</div>

        </div>

        <footer class="my-sm-10 sticky">
          <div class="container my-auto"> 
            <div class="copyright text-center">
              <span>Copyright © BLACKNET by <a href="http://www.twitter.com/BlackHacker_511">Black.Hacker</a> - <?php echo date('Y'); ?> 
              <br></span>
            </div>
          </div>
        </footer>

	    <a class="scroll-to-top rounded" href="#page-top">
	      <i class="fas fa-angle-up"></i>
	    </a>

	  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	    <div class="modal-dialog" role="document">
	      <div class="modal-content">
	        <div class="modal-header">
	          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
	          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
	            <span aria-hidden="true">×</span>
	          </button>
	        </div>
	        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
	        <div class="modal-footer">
	          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
	          <a class="btn btn-primary" href="logout.php">Logout</a>
	        </div>
	      </div>
	    </div>
	  </div>
    <script src="asset/vendor/jquery/jquery.min.js"></script>
    <script src="asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="asset/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="asset/vendor/datatables/jquery.dataTables.js"></script>
    <script src="asset/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="asset/js/sb-admin.min.js"></script>
    <script src="asset/js/demo/datatables-demo.js"></script>
    <script src="asset/js/bootstrap-switch/main.js"></script>
    <script src="asset/js/bootstrap-switch/highlight.js"></script>
    <script src="asset/js/bootstrap-switch/bootstrap-switch.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
    $("#show_hide_password a").on('click', function(event) {
        event.preventDefault();
        if($('#SMTPPassword input').attr("type") == "text"){
            $('#SMTPPassword input').attr('type', 'password');
            $('#show_hide_password i').addClass( "fa-eye-slash" );
            $('#show_hide_password i').removeClass( "fa-eye" );
        }else if($('#SMTPPassword input').attr("type") == "password"){
            $('#SMTPPassword input').attr('type', 'text');
            $('#show_hide_password i').removeClass( "fa-eye-slash" );
            $('#show_hide_password i').addClass( "fa-eye" );
        }
    });
});
    </script>
  </body>
</html>