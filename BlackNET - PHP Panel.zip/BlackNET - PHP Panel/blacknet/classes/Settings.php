<?php
class Settings extends Database{
	public function getSettings($id){
	$pdo = $this->Connect();
	$sql = "SELECT * FROM settings WHERE id = :id";
	$stmt = $pdo->prepare($sql);
	$stmt->execute(['id' => $id]);
	$data = $stmt->fetch();
	return $data;
	}

	public function updateSettings($id,$recaptchaprivate,$recaptchapublic,$recaptchastatus){
		$pdo = $this->Connect();
        $settings = $this->getSettings($id);

        if ($settings->recaptchaprivate == $recaptchaprivate) {
                $newRCP = $settings->recaptchaprivate;
            } else {
                $newRCP = $recaptchaprivate;
            }

            if ($settings->recaptchapublic == $recaptchapublic) {
                $newRCPub = $settings->recaptchapublic;
            } else {
                $newRCPub = $recaptchapublic;
            }

            if ($recaptchastatus == "") {
                $status = "off";
            } else {
                $status = "on";
            }

        $sql = "UPDATE settings SET recaptchaprivate = :private,recaptchapublic = :public,recaptchastatus = :status WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['private'=>$newRCP,'public'=>$newRCPub,'status'=>$status,'id'=>$id]);
        return 'Settings Updated';
	}
}
?>