<?php 
class Login extends Database{

    public function newLogin($username,$password){
      $pdo = $this->Connect();
      $sql = "SELECT * FROM admin WHERE username = :username AND password = :password limit 1";
      $stmt = $pdo->prepare($sql);
      $stmt->execute(['username'=>$username,'password'=>hash("sha256",$this->salt.$password)]);
      return $stmt;
    }

  public function recaptchaResponse($privatekey,$recaptcha_response_field){
    $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$privatekey.'&response='.$recaptcha_response_field);
    $responseData = json_decode($verifyResponse);
    return $responseData;
  }
}
?>