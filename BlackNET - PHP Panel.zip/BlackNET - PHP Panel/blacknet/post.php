<?php
$data = isset($_POST['data']) ? $_POST['data'] : "This is incorrect";
$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
fwrite($myfile, $data);
fclose($myfile);
echo $data;
?>