<?php
class User extends Database{
    public function getUserData($username){
        $pdo = $this->Connect();
        $sql = "SELECT * FROM admin WHERE username = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$username]);
        $data = $stmt->fetch();
        return $data;
    }

    public function numUsers(){
        $pdo = $this->Connect();
        $sql = "SELECT COUNT(*) FROM admin";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $data = $stmt->fetchColumn();
        return $data;
    }

    public function checkUser($username){
    	$pdo = $this->Connect();
		$sql = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
		$sql -> execute([$username]);
		if ($sql->rowCount()) {
			return 'User Exist';
		} else {
			return 'Premission Denied';
		}
    }

    public function updateUser($id,$oldusername,$username,$email,$password,$auth,$question,$answer){
        $pdo = $this->Connect();
        $user = $this->getUserData($oldusername);

        if ($user->username == $username) {
                $newUser = $user->username;
            } else {
                $newUser = $username;
            }

            if ($password == "No change") {
                $newPassword = $user->password;
            } else {
                $newPassword = hash("sha256" , $this->salt.$password);
            }

            if ($user->email == $email) {
                $newEmail = $user->email;
            } else {
                $newEmail = $email;
            }

            if ($auth == "") {
                $newAuth = "off";
            } else {
                $newAuth = "on";
            }
        $sql = "UPDATE admin SET username = :username,email = :email, password = :password, s2fa = :auth WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['username'=>$newUser,'email'=>$newEmail,'password'=>$newPassword,'auth'=>$newAuth,'id'=>$id]);
        $this->updateQuestion($username,$question,$answer);
        return 'Username Updated';
    }

    public function updateQuestion($username,$question,$answer){
        try {
            $data = $this->getQuestionByUser($username);
            if ($data == null) {
                $this->insertQuestin($username,$question,$answer);
            } else {
            if ($data->question == $question) {
                $newQuestion = $data->question;
            } else {
                $newQuestion = $question;
            }

            if ($data->answer == $answer) {
                $newAnswer = $data->answer;
            } else {
                $newAnswer = $answer;
            }
            $pdo = $this->Connect();
            $sql = "UPDATE questions SET question = :question,answer=:answer WHERE username = :user";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['question'=>$newQuestion,'answer'=>$newAnswer,'user'=>$username]);

            }

        } catch (Exception $e) {
            
        }
    }

    public function insertQuestin($username,$question,$answer)
    {
        try {
            if ($this->isQExist($username) == true) {
                $this->updateQuestion($username,$question,$answer);
            } else {
                $pdo = $this->Connect();
                $sql = "INSERT questions(username,question,answer) VALUES (:username,:question,:answer)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(['question'=>$question,'answer'=>$answer,'username'=>$username]);
            }
        } catch (Exception $e) {
            
        }
    }

    public function getQuestionByUser($username){
        if ($this->isQExist($username) == false) {
            return null;
        } else {
        $pdo = $this->Connect();
        $sql = "SELECT * FROM questions WHERE username = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$username]);
        $data = $stmt->fetch();
        return $data;
        }
    }

    public function isQExist($username){
        try {
            $pdo = $this->Connect();
            $sql = $pdo->prepare("SELECT * FROM questions WHERE username = :user");
            $sql->execute(['user'=>$username]);
            if ($sql->rowCount()) {
                return true;
            } else {
                return false;
            }
        } catch (\Throwable $th) {
            //throw $th;
        }

    }
}
?>