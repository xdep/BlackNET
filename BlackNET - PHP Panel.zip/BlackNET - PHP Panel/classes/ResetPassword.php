<?php
class ResetPassword extends User {
	public function generateToken(){
		return sha1(base64_encode(uniqid(rand(), true)));
	}
	
	public function sendEmail($username){
		$pdo = $this->Connect();
		$sendmail = new Mailer;
		try {
		   if ($this->checkUser($username) != "User Exist") {
		    return "Username does not exist!";
		   } else {
		    $token = $this->generateToken();
		    $rows = $this->getUserData($username);
		    $email = $rows->email;
			$sql = "INSERT INTO confirm_code (username,token) VALUES (:username,:token)";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['username'=>$username,'token'=>$token]);
			$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")."://".$this->getDir();
		    $sendmail->mailto($email, "Reset BlackNET Password" ,"Hello $username <br /> Password Rest URL: <a href='".$actual_link."reset.php?key=$token'>Click Here</a> <br /> if the URL does not work your token is $token <br /> Enjoy");
		    return true;
		 }
		} catch (Exception $e) {
			
		}
 }
	 public function updatePassword($key,$username,$password)
	 {
	 		$pdo = $this->Connect();
		 if (strlen($password) >= 8) {
			$sql = "UPDATE admin SET password = :password WHERE username = :username";
			$stmt = $pdo->prepare($sql);
			$stmt->execute(['username'=>$username,'password'=>hash("sha256",$this->salt.$password)]);
			$this->expireKey($key);
	    	return "Password Has Been Updated"; 
	    } else {
	      return 'Please enter more then 8 characters';
	    }
	 }

	 public function getUserAssignToToken($token)
	 {
	 	$pdo = $this->Connect();
        $sql = "SELECT * FROM confirm_code WHERE token = ? limit 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$token]);
        $data = $stmt->fetch();
        return $data;
	 }

	 public function deleteToken($token){
		try {
			$pdo = $this->Connect();
			$sql = "DELETE FROM confirm_code WHERE token = ?";
			$stmt = $pdo->prepare($sql);
			$stmt->execute([$token]);
			return 'Client Removed';
		} catch (\Throwable $th) {
			//throw $th;
		}
	 }

	 public function isExist($key){
		try {
			$pdo = $this->Connect();
			$sql = $pdo->prepare("SELECT * FROM confirm_code WHERE token = :id");
			$sql->execute(['id'=>$key]);
			if ($sql->rowCount()) {
				if ($this->isExpired($key) == "Key expired") {
					return "Incorrect";
				} else {
				return "Key Exist";
				}
			} else {
				return "Incorrect";
			}
		} catch (\Throwable $th) {
			//throw $th;
		}
	 }

	 public function isExpired($key)
	 {
		try {
			$pdo = $this->Connect();
			$sql = $pdo->prepare("SELECT * FROM confirm_code WHERE token = :id");
			$sql->execute(['id'=>$key]);
			$data = $sql->fetch();
			if ($data->expire=="expired") {
				return "Key expired";
			} else {
				return "Key is Good";
			}
		} catch (\Throwable $th) {
			//throw $th;
		}
	 }

	 public function expireKey($key){
	 	try {
		 	$pdo = $this->Connect();
		 	$sql = $pdo->prepare("UPDATE confirm_code SET expire = :status WHERE token = :token");
		 	$sql->execute(['status'=>"expired",'token'=>$key]);
		 	return "Key has been expired";
	 	} catch (Exception $e) {
	 		return "Error";
	 		
	 	}
	 }

	 private function getDir(){
	 	$url = $_SERVER['REQUEST_URI']; //returns the current URL
		$parts = explode('/',$url);
		$dir = $_SERVER['SERVER_NAME'];
		for ($i = 0; $i < count($parts) - 1; $i++) {
			$dir .= $parts[$i] . "/";
		}
		return $dir;
	 }
}
?>