<?php

class Auth extends User{
	public function generateCode(){
		return rand(000000,999999);
	}

	function generateSecret($length = 63) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*()-=_+[]{}|;:,./<>?';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}

	public function updateCode($username,$code,$secret){
		$pdo = $this->Connect();
        $sql = "UPDATE auth SET code = :code, secret = :secret WHERE username = :username";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['username'=>$username,'code'=>hash("sha256", $secret.$code),'secret'=>$secret]);
	}

	public function newCode($username,$code){
		try {
			$pdo = $this->Connect();
			$secret = $this->generateSecret();
			if ($this->isExist($username) == true) {
				$this->updateCode($username,$code,$secret);
			} else {
				$pdo = $this->Connect();
				$sql = "INSERT INTO auth(username,code,secret) VALUES (:username,:code,:secret)";
				$stmt = $pdo->prepare($sql);
				$stmt->execute(['username'=>$username,'code'=>hash("sha256", $secret.$code),'secret'=>$secret]);
				return 'Code Created';
			}
			if ($this->sendEmail($username,$code)) {
				return true;
			} else {
				return false;
			}
		} catch (Exception $e) {
			
		}
	}

	public function isExist($username){
		$pdo = $this->Connect();
		$sql = $pdo->prepare("SELECT * FROM auth WHERE username = ?");
		$sql -> execute([$username]);
		if ($sql->rowCount()) {
			return true;
		} else {
			return false;
		}
	}

	public function sendEmail($username,$code){
		$smtp = new Mailer;
        $pdo = $this->Connect();
        $data = $this->getUserData($username);
        $email = $data->email;
        if ($smtp->mailto($email,"BlackNET 2FA Code","<p>Welcome User <br /> Your 2FA Code: $code <br /> Enjoy</p>")) {
        	return true;
        } else {
        	return false;
        }
	}

	public function getCode($username){
        $pdo = $this->Connect();
        $sql = "SELECT code,secret FROM auth WHERE username = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$username]);
        $data = $stmt->fetch();
        return $data;
	}
}

?>