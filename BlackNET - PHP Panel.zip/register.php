<?php
include 'config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {
if (isset($_POST['Username']) && isset($_POST['Password']) && isset($_POST['confirmPassword'])) {
  $Username = $_POST['Username'];
  $Password = md5($_POST['Password']);
  $confirmPassword = md5($_POST['confirmPassword']);
  if (checkExist($Username) == True) {
  $errmsg = "Username Exist";
} else {
  if ($Password == $confirmPassword) {
    $regquiry = "INSERT INTO admin (username,password,role) VALUES ('$Username','$Password','administrator')";
    $newcuser = mysqli_query($conn,$regquiry);
    $msg = "Account Has Been Created";
  } else {
    $errmsg = "Password Confirm is incorrect";
  }
}
}
 
}

function checkExist($CheckUser) {
  include 'config.php';
    $checkquiry = "SELECT * FROM admin";
    $getuser = mysqli_query($conn,$checkquiry);
while ($rows = mysqli_fetch_array($getuser, MYSQLI_ASSOC)) {
    if($rows['username'] == $CheckUser){
      return True;
      } else {
        return False;
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>BlackNET - Register User</title>
    <link href="asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="asset/css/sb-admin.css" rel="stylesheet">
  </head>
  <body class="bg-dark">
    <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header">Register an Account</div>
        <div class="card-body">
          <form method="POST">
            <div class="form-group">
                  <div class="form-label-group">
                    <input type="text" id="Username" name="Username" class="form-control" placeholder="Username" required="required" autofocus="autofocus">
                    <label for="Username">Username</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" name="Password" id="inputPassword" class="form-control" placeholder="Password" required="required">
                    <label for="inputPassword">Password</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" name="confirmPassword" id="confirmPassword" class="form-control" placeholder="Confirm password" required="required">
                    <label for="confirmPassword">Confirm password</label>
                  </div>
                </div>
              </div>
            </div>
            <button class="btn btn-primary btn-block" type="submit">Register</button>
            <?php 
if (isset($msg)){
  echo $msg;
} elseif (isset($errmsg)) {
  echo $errmsg;
} else {
}

            ?>
          </form>
          <div class="text-center">
            <a class="d-block small mt-3" href="login.php">Login Page</a>
          </div>
        </div>
      </div>
    </div>
    <script src="asset/vendor/jquery/jquery.min.js"></script>
    <script src="asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="asset/vendor/jquery-easing/jquery.easing.min.js"></script>
  </body>
</html>
